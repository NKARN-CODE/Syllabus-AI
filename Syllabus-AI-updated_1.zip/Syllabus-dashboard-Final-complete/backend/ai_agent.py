"""
AI agent orchestration layer.

This module is an INTERFACE to the app's existing functionality, not a
new business-logic layer. Every tool below ultimately calls a function
that already exists in main.py / exams.py / resources.py — nothing here
duplicates chapter, exam, or resource logic.

Supports multiple LLM providers behind one agent loop:
  - anthropic  (Claude, native tool-use format)
  - openai     (OpenAI, function-calling format)
  - nim        (NVIDIA NIM — OpenAI-compatible endpoint, same adapter as openai)

The provider actually used at any moment is whatever is saved in
ai_settings (see ai_settings.py) — switchable from the Settings page
without restarting the server.

Architectural rule: this module never touches SQLite directly except
through the existing app modules (db, exams_mod, resources_mod,
activity_mod). Claude/the model never sees a database connection —
it only ever requests "call this tool with these arguments," and
execute_tool() is the only thing that acts on that request.
"""
import json
from datetime import date

from db import get_conn, QUICK_STATUS_MAP
import exams as exams_mod
import resources as resources_mod
import activity as activity_mod
import goals as goals_mod
import analytics as analytics_mod
import ai_settings

MAX_AGENT_TURNS = 8  # hard ceiling so a stuck loop can't run forever


# ── Tool definitions (provider-neutral: name, description, JSON schema) ──

TOOL_DEFS = [
    {
        "name": "find_chapter",
        "description": (
            "Search chapters by name and/or subject to get their exact numeric ID. "
            "ALWAYS call this before update_chapter_status or toggle_resource if you "
            "don't already have the exact chapter_id from earlier in this conversation. "
            "Never guess or invent a chapter_id."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "name_contains": {"type": "string", "description": "Partial or full chapter name to search for."},
                "subject": {"type": "string", "description": "Optional subject to narrow the search."},
            },
            "required": ["name_contains"],
        },
    },
    {
        "name": "create_chapter",
        "description": (
            "Create a new chapter under a subject. Use this when the user asks to add one or "
            "more chapters/topics that don't exist yet — e.g. 'add Tenses, Modals, and Reported "
            "Speech to English'. Call this once per chapter. If the subject doesn't exist yet in "
            "this app, it will be created automatically the first time a chapter uses it."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "subject": {"type": "string", "description": "Subject the chapter belongs to, e.g. 'English'."},
                "name": {"type": "string", "description": "Chapter/topic name, e.g. 'Tenses'."},
                "priority": {"type": "string", "enum": ["Must", "Should", "Later"], "description": "Optional, defaults to 'Should'."},
                "difficulty": {"type": "string", "enum": ["Easy", "Medium", "Hard"], "description": "Optional, defaults to 'Medium'."},
            },
            "required": ["subject", "name"],
        },
    },
    {
        "name": "update_chapter_status",
        "description": (
            "Change a chapter's study status. Use this when the user says they finished, "
            "practiced, need to revise, or haven't started a specific chapter. Requires the "
            "exact chapter_id — call find_chapter first if you don't already have it."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "chapter_id": {"type": "integer", "description": "The chapter's numeric ID, from find_chapter."},
                "quick_status": {
                    "type": "string",
                    "enum": list(QUICK_STATUS_MAP.keys()),
                    "description": "One of: not_started, practice, revision, completed.",
                },
            },
            "required": ["chapter_id", "quick_status"],
        },
    },
    {
        "name": "create_exam",
        "description": "Create a new exam/deadline entry.",
        "input_schema": {
            "type": "object",
            "properties": {
                "name": {"type": "string"},
                "date": {"type": "string", "description": "ISO date, e.g. 2026-10-18. Optional."},
                "exam_type": {
                    "type": "string",
                    "enum": ["Board", "Preboard", "Mock Test", "Scholarship", "Competition", "Class Test", "Other"],
                },
                "priority": {"type": "string", "enum": ["Must", "Should", "Later"]},
            },
            "required": ["name"],
        },
    },
    {
        "name": "toggle_resource",
        "description": (
            "Mark a specific resource (textbook, tuition1, qb, etc.) done or not-done for one "
            "chapter. Requires the exact chapter_id — call find_chapter first if needed. The "
            "valid resource_key values depend on the chapter's subject; if unsure, call "
            "find_resources_not_done first to see what's actually tracked for that chapter."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "chapter_id": {"type": "integer"},
                "resource_key": {
                    "type": "string",
                    "enum": list(resources_mod.RESOURCE_TYPES.keys()),
                },
                "is_done": {"type": "boolean"},
            },
            "required": ["chapter_id", "resource_key", "is_done"],
        },
    },
    {
        "name": "find_resources_not_done",
        "description": (
            "List resources that are not yet marked done, optionally filtered to one chapter "
            "or one subject. Use this to answer questions like 'what's left for Trigonometry' "
            "or to discover a chapter's valid resource_key values before calling toggle_resource."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "chapter_id": {"type": "integer", "description": "Optional — limit to one chapter."},
                "subject": {"type": "string", "description": "Optional — limit to one subject."},
            },
        },
    },
    {
        "name": "list_exams",
        "description": (
            "List all exams/deadlines with their real countdown (days_left) and prep readiness "
            "(what fraction of linked chapters are actually ready). Use this for any question about "
            "upcoming exams, deadlines, or how prepared the user is for something. Sorted soonest first."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "include_completed": {"type": "boolean", "description": "Include exams already marked completed. Defaults to false."},
            },
        },
    },
    {
        "name": "list_chapters",
        "description": (
            "List chapters, optionally filtered by subject and/or status. Use this for any question "
            "that asks to see, list, or count multiple chapters — e.g. 'what needs revision', "
            "'what's left in Physics', 'what have I completed'. Returns id, subject, name, status "
            "for each match, capped at 50 results."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "subject": {"type": "string", "description": "Optional — limit to one subject."},
                "status": {
                    "type": "string",
                    "enum": ["Not started", "Learning", "Practice", "First pass done", "Tested", "Needs revision"],
                    "description": "Optional — limit to chapters with exactly this status.",
                },
            },
        },
    },
    {
        "name": "update_chapter_details",
        "description": (
            "Edit a chapter's priority, difficulty, or notes. Use this for requests like 'make "
            "Trigonometry high priority' or 'mark Optics as hard' — NOT for status changes, which "
            "go through update_chapter_status instead. Requires the exact chapter_id — call "
            "find_chapter first if you don't already have it. Only pass the fields being changed."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "chapter_id": {"type": "integer"},
                "priority": {"type": "string", "enum": ["Must", "Should", "Later"]},
                "difficulty": {"type": "string", "enum": ["Easy", "Medium", "Hard"]},
                "notes": {"type": "string", "description": "Replaces the chapter's notes entirely."},
            },
            "required": ["chapter_id"],
        },
    },
    {
        "name": "link_chapter_to_exam",
        "description": (
            "Link a chapter to an exam so it counts toward that exam's readiness percentage. Use "
            "this when the user says a chapter is 'for' or 'on' a specific exam, e.g. 'Trigonometry "
            "is on the midterm'. Requires exact chapter_id and exam_id — call find_chapter and "
            "list_exams first if you don't already have them."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "chapter_id": {"type": "integer"},
                "exam_id": {"type": "integer"},
                "finish_by": {"type": "string", "description": "Optional ISO date this chapter should be ready by, e.g. 2026-10-18."},
            },
            "required": ["chapter_id", "exam_id"],
        },
    },
    {
        "name": "mark_exam_completed",
        "description": (
            "Mark an exam as completed/done, e.g. after the user says they took it or it has "
            "passed. Requires the exact exam_id — call list_exams first if you don't already have it."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "exam_id": {"type": "integer"},
            },
            "required": ["exam_id"],
        },
    },
    {
        "name": "create_goal",
        "description": (
            "Create a tracked goal, e.g. 'finish all of Physics by November' or 'complete 20 "
            "chapters this month'. target_type 'chapter_count' tracks a raw count; 'subject_completion' "
            "tracks percent-complete for one subject; 'custom' has no automatic progress tracking."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "title": {"type": "string"},
                "target_type": {"type": "string", "enum": ["chapter_count", "subject_completion", "custom"]},
                "subject": {"type": "string", "description": "Required if target_type is subject_completion."},
                "target_value": {"type": "integer", "description": "Required if target_type is chapter_count."},
                "target_date": {"type": "string", "description": "Optional ISO date deadline, e.g. 2026-11-30."},
            },
            "required": ["title", "target_type"],
        },
    },
    {
        "name": "get_progress_summary",
        "description": (
            "One-call overview: overall completion %, current streak, and the single nearest exam "
            "with its readiness. Use this for broad questions like 'how am I doing' or 'give me a "
            "status update' instead of calling list_exams and list_chapters separately."
        ),
        "input_schema": {"type": "object", "properties": {}},
    },
]


# ── System prompt (condensed app context, not the full APP_REFERENCE) ──

def _build_system_prompt():
    with get_conn() as conn:
        subjects = [r["subject"] for r in conn.execute(
            "SELECT DISTINCT subject FROM chapter WHERE is_placeholder = 0 ORDER BY subject"
        ).fetchall()]

    subjects_with_resources = sorted(resources_mod.SUBJECT_RESOURCE_RULES.keys())
    resource_lines = "\n".join(
        f"  - {key}: {info['label']}" for key, info in resources_mod.RESOURCE_TYPES.items()
    )

    return f"""You are the AI assistant embedded in a personal syllabus/study tracker app.

SUBJECTS IN THIS APP: {', '.join(subjects) if subjects else '(none yet)'}
Subjects that have a tracked resource checklist: {', '.join(subjects_with_resources)}

CHAPTER QUICK-STATUS VALUES (use exactly these words with update_chapter_status):
  - not_started
  - practice
  - revision
  - completed

RESOURCE KEYS (use exactly these with toggle_resource):
{resource_lines}

CRITICAL RULE — NEVER GUESS AN ID:
Chapter IDs are internal database numbers you cannot know in advance. If the user
refers to a chapter by name and you do not already have its exact chapter_id from
earlier in this same conversation, you MUST call find_chapter first and use the ID
it returns. Never invent, assume, or pattern-match a plausible-looking ID.

ANSWERING QUESTIONS ABOUT WHAT EXISTS:
Never say you can't see or don't have access to the user's data — you do, through
tools. If asked about upcoming exams or deadlines, call list_exams. If asked to
list, count, or find chapters by subject or status (e.g. "what needs revision",
"what's left in Physics", "what have I completed"), call list_chapters. Only tell
the user something isn't possible if no tool actually covers it (e.g. deletion).

CREATING CHAPTERS:
If the user asks to add one or more chapters/topics, call create_chapter once per
chapter — do not tell them to use the app's UI instead, that tool exists for
exactly this. If they list several at once ("add Tenses, Modals, and Reported
Speech to English"), call create_chapter separately for each one in the same turn.

DESTRUCTIVE ACTIONS:
You have no delete capability. If the user asks to delete a chapter, exam, or
resource, tell them this assistant can't do that — they should use the app's UI
directly for deletions.

Be concise. After completing the requested actions, reply with a short plain-text
confirmation of what you did. Do not narrate intermediate tool calls to the user."""


# ── execute_tool: the ONLY bridge between the model and the app ──

def execute_tool(name: str, args: dict) -> dict:
    """Dispatches a tool call to existing app logic. Never raises — always
    returns a dict, so a bad call can be reported back to the model instead
    of crashing the request."""
    try:
        if name == "find_chapter":
            return _find_chapter(args.get("name_contains", ""), args.get("subject"))
        elif name == "create_chapter":
            return _create_chapter(args)
        elif name == "update_chapter_status":
            return _update_chapter_status(args.get("chapter_id"), args.get("quick_status"))
        elif name == "create_exam":
            return _create_exam(args)
        elif name == "toggle_resource":
            return _toggle_resource(args.get("chapter_id"), args.get("resource_key"), args.get("is_done"))
        elif name == "find_resources_not_done":
            return _find_resources_not_done(args.get("chapter_id"), args.get("subject"))
        elif name == "list_exams":
            return _list_exams(args.get("include_completed", False))
        elif name == "list_chapters":
            return _list_chapters(args.get("subject"), args.get("status"))
        elif name == "update_chapter_details":
            return _update_chapter_details(args)
        elif name == "link_chapter_to_exam":
            return _link_chapter_to_exam(args.get("chapter_id"), args.get("exam_id"), args.get("finish_by"))
        elif name == "mark_exam_completed":
            return _mark_exam_completed(args.get("exam_id"))
        elif name == "create_goal":
            return _create_goal(args)
        elif name == "get_progress_summary":
            return _get_progress_summary()
        else:
            return {"error": f"Unknown tool '{name}'"}
    except Exception as e:  # last-resort guard — a tool must never crash the agent loop
        return {"error": f"Tool '{name}' failed: {e}"}


def _find_chapter(name_contains: str, subject: str = None) -> dict:
    if not name_contains:
        return {"error": "name_contains is required"}
    query = "SELECT id, subject, name, status FROM chapter WHERE is_placeholder = 0 AND name LIKE ?"
    params = [f"%{name_contains}%"]
    if subject:
        query += " AND subject = ?"
        params.append(subject)
    query += " ORDER BY name LIMIT 10"
    with get_conn() as conn:
        rows = [dict(r) for r in conn.execute(query, params).fetchall()]
    if not rows:
        return {"error": f"No chapter found matching '{name_contains}'" + (f" in {subject}" if subject else "")}
    return {"matches": rows}


def _create_chapter(args: dict) -> dict:
    subject = args.get("subject")
    name = args.get("name")
    if not subject or not name:
        return {"error": "subject and name are both required"}
    priority = args.get("priority") or "Should"
    difficulty = args.get("difficulty") or "Medium"

    with get_conn() as conn:
        existing = conn.execute(
            "SELECT id FROM chapter WHERE subject = ? AND name = ? AND is_placeholder = 0",
            (subject, name),
        ).fetchone()
        if existing:
            return {"error": f"'{name}' already exists in {subject} (id {existing['id']})"}
        cur = conn.execute(
            """INSERT INTO chapter (subject, name, board_scope, status, priority, effort_weight, difficulty, is_placeholder, notes)
               VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?)""",
            (subject, name, "None", "Not started", priority, 3, difficulty, ""),
        )
        chapter_id = cur.lastrowid
    activity_mod.log(chapter_id, "created", to_status="Not started", note="[AI] created chapter")
    resources_mod.sync_chapter_resources(chapter_id, subject)
    return {"ok": True, "chapter_id": chapter_id, "subject": subject, "name": name}


def _update_chapter_status(chapter_id, quick_status) -> dict:
    if chapter_id is None:
        return {"error": "chapter_id is required — call find_chapter first"}
    if quick_status not in QUICK_STATUS_MAP:
        return {"error": f"quick_status must be one of {list(QUICK_STATUS_MAP.keys())}"}
    with get_conn() as conn:
        row = conn.execute("SELECT id, name, subject, status FROM chapter WHERE id = ?", (chapter_id,)).fetchone()
        if not row:
            return {"error": f"No chapter with id {chapter_id}. Call find_chapter to get a valid ID."}
        old_status = row["status"]
        new_status = QUICK_STATUS_MAP[quick_status]
        conn.execute(
            "UPDATE chapter SET status = ?, last_studied = ? WHERE id = ?",
            (new_status, date.today().isoformat(), chapter_id),
        )
    if new_status != old_status:
        activity_mod.log(chapter_id, "status_change", from_status=old_status, to_status=new_status,
                          note=f"[AI] set {row['name']} to {new_status}")
    return {"ok": True, "chapter_id": chapter_id, "name": row["name"], "subject": row["subject"], "new_status": new_status}


def _create_exam(args: dict) -> dict:
    name = args.get("name")
    if not name:
        return {"error": "name is required"}
    exam_id = exams_mod.create_exam(
        name=name,
        date_=args.get("date"),
        time_=None,
        priority=args.get("priority") or "Should",
        notes="",
        exam_type=args.get("exam_type") or "Other",
    )
    if exam_id is None:
        return {"error": f"An exam named '{name}' already exists"}
    activity_mod.log(None, "created", note=f"[AI] created exam '{name}'")
    return {"ok": True, "exam_id": exam_id, "name": name}


def _toggle_resource(chapter_id, resource_key, is_done) -> dict:
    if chapter_id is None or resource_key is None or is_done is None:
        return {"error": "chapter_id, resource_key, and is_done are all required"}
    if resource_key not in resources_mod.RESOURCE_TYPES:
        return {"error": f"'{resource_key}' is not a valid resource_key. Valid keys: {list(resources_mod.RESOURCE_TYPES.keys())}"}
    with get_conn() as conn:
        chapter = conn.execute("SELECT id, name FROM chapter WHERE id = ?", (chapter_id,)).fetchone()
    if not chapter:
        return {"error": f"No chapter with id {chapter_id}. Call find_chapter to get a valid ID."}
    changed = resources_mod.toggle_resource(chapter_id, resource_key, bool(is_done))
    if not changed:
        return {"error": f"Chapter {chapter_id} does not track resource '{resource_key}' (wrong subject?). "
                          f"Call find_resources_not_done to see what it actually tracks."}
    label = resources_mod.resource_label(resource_key)
    activity_mod.log(chapter_id, "study_session",
                      note=f"[AI] {label} marked {'done' if is_done else 'not done'} on {chapter['name']}")
    return {"ok": True, "chapter_id": chapter_id, "resource_key": resource_key, "label": label, "is_done": bool(is_done)}


def _find_resources_not_done(chapter_id=None, subject=None) -> dict:
    if chapter_id is not None:
        with get_conn() as conn:
            chapter = conn.execute("SELECT id, name FROM chapter WHERE id = ?", (chapter_id,)).fetchone()
        if not chapter:
            return {"error": f"No chapter with id {chapter_id}"}
        items = [r for r in resources_mod.get_chapter_resources(chapter_id) if not r["is_done"]]
        return {"chapter": chapter["name"], "not_done": [{"resource_key": r["resource_key"], "label": r["label"]} for r in items]}

    overview = resources_mod.overview()
    result = []
    for entry in overview:
        chapters = entry["not_done_chapters"]
        if subject:
            chapters = [c for c in chapters if c["subject"] == subject]
        if chapters:
            result.append({"resource_key": entry["key"], "label": entry["label"], "not_done_chapters": chapters})
    return {"not_done_by_resource": result}


def _list_exams(include_completed=False) -> dict:
    exams = exams_mod.list_exams()
    if not include_completed:
        exams = [e for e in exams if not e["is_completed"]]
    if not exams:
        return {"exams": [], "note": "No exams found." + ("" if include_completed else " (completed exams are hidden — pass include_completed=true to see them)")}
    return {
        "exams": [
            {
                "id": e["id"],
                "name": e["name"],
                "exam_type": e["exam_type"],
                "priority": e["priority"],
                "days_left": e["days_left"],
                "effective_date": e["effective_date"],
                "is_overdue": e["is_overdue"],
                "chapters_ready": e["chapters_ready"],
                "chapters_total": e["chapters_total"],
                "readiness_pct": e["readiness_pct"],
            }
            for e in exams
        ]
    }


def _list_chapters(subject=None, status=None) -> dict:
    query = "SELECT id, subject, name, status FROM chapter WHERE is_placeholder = 0"
    params = []
    if subject:
        query += " AND subject = ?"
        params.append(subject)
    if status:
        query += " AND status = ?"
        params.append(status)
    query += " ORDER BY subject, name LIMIT 50"
    with get_conn() as conn:
        rows = [dict(r) for r in conn.execute(query, params).fetchall()]
    if not rows:
        return {"chapters": [], "note": "No chapters matched that filter."}
    return {"chapters": rows, "count": len(rows)}


def _update_chapter_details(args: dict) -> dict:
    chapter_id = args.get("chapter_id")
    if chapter_id is None:
        return {"error": "chapter_id is required — call find_chapter first"}
    fields = {k: args[k] for k in ("priority", "difficulty", "notes") if args.get(k) is not None}
    if not fields:
        return {"error": "Nothing to update — pass at least one of priority, difficulty, notes"}
    with get_conn() as conn:
        row = conn.execute("SELECT id, name, subject FROM chapter WHERE id = ?", (chapter_id,)).fetchone()
        if not row:
            return {"error": f"No chapter with id {chapter_id}. Call find_chapter to get a valid ID."}
        set_clause = ", ".join(f"{k} = ?" for k in fields)
        conn.execute(f"UPDATE chapter SET {set_clause} WHERE id = ?", list(fields.values()) + [chapter_id])
    return {"ok": True, "chapter_id": chapter_id, "name": row["name"], "subject": row["subject"], "updated": fields}


def _link_chapter_to_exam(chapter_id, exam_id, finish_by=None) -> dict:
    if chapter_id is None or exam_id is None:
        return {"error": "chapter_id and exam_id are both required"}
    with get_conn() as conn:
        chapter = conn.execute("SELECT id, name FROM chapter WHERE id = ?", (chapter_id,)).fetchone()
        exam = conn.execute("SELECT id, name FROM exam_target WHERE id = ?", (exam_id,)).fetchone()
    if not chapter:
        return {"error": f"No chapter with id {chapter_id}. Call find_chapter to get a valid ID."}
    if not exam:
        return {"error": f"No exam with id {exam_id}. Call list_exams to get a valid ID."}
    exams_mod.link_chapter(exam_id, chapter_id, finish_by)
    activity_mod.log(chapter_id, "study_session", note=f"[AI] linked {chapter['name']} to exam '{exam['name']}'")
    return {"ok": True, "chapter_id": chapter_id, "chapter_name": chapter["name"], "exam_id": exam_id, "exam_name": exam["name"]}


def _mark_exam_completed(exam_id) -> dict:
    if exam_id is None:
        return {"error": "exam_id is required — call list_exams first"}
    with get_conn() as conn:
        exam = conn.execute("SELECT id, name FROM exam_target WHERE id = ?", (exam_id,)).fetchone()
    if not exam:
        return {"error": f"No exam with id {exam_id}. Call list_exams to get a valid ID."}
    ok = exams_mod.update_exam(exam_id, {"is_completed": 1})
    if not ok:
        return {"error": f"Could not update exam {exam_id}"}
    activity_mod.log(None, "study_session", note=f"[AI] marked exam '{exam['name']}' completed")
    return {"ok": True, "exam_id": exam_id, "name": exam["name"]}


def _create_goal(args: dict) -> dict:
    title = args.get("title")
    target_type = args.get("target_type")
    if not title or not target_type:
        return {"error": "title and target_type are both required"}
    if target_type == "subject_completion" and not args.get("subject"):
        return {"error": "subject is required when target_type is subject_completion"}
    if target_type == "chapter_count" and args.get("target_value") is None:
        return {"error": "target_value is required when target_type is chapter_count"}
    goal_id = goals_mod.create_goal(
        title=title,
        target_type=target_type,
        subject=args.get("subject"),
        target_value=args.get("target_value"),
        target_date=args.get("target_date"),
    )
    activity_mod.log(None, "created", note=f"[AI] created goal '{title}'")
    return {"ok": True, "goal_id": goal_id, "title": title}


def _get_progress_summary() -> dict:
    overview = analytics_mod.overview()
    streak_info = activity_mod.streak()
    exams = exams_mod.list_exams()
    upcoming = sorted((e for e in exams if not e["is_completed"]), key=lambda e: (e["days_left"] if e["days_left"] is not None else 9999))
    nearest = upcoming[0] if upcoming else None
    return {
        "completion_pct": overview["completion_pct"],
        "total_chapters": overview["total"],
        "tested_chapters": overview["tested"],
        "needs_revision": overview["needs_revision"],
        "current_streak": streak_info["current_streak"],
        "nearest_exam": {
            "name": nearest["name"], "days_left": nearest["days_left"], "readiness_pct": nearest["readiness_pct"],
        } if nearest else None,
    }


# ── Provider adapters ──────────────────────────────────────────────

def _anthropic_tool_schemas():
    return [{"name": t["name"], "description": t["description"], "input_schema": t["input_schema"]} for t in TOOL_DEFS]


def _openai_tool_schemas():
    return [
        {"type": "function", "function": {"name": t["name"], "description": t["description"], "parameters": t["input_schema"]}}
        for t in TOOL_DEFS
    ]


class AnthropicAdapter:
    """Native Anthropic Messages API tool-use format."""

    def __init__(self, api_key: str, model: str):
        import anthropic
        self.client = anthropic.Anthropic(api_key=api_key)
        self.model = model or "claude-sonnet-5"

    def call(self, messages, system_prompt):
        response = self.client.messages.create(
            model=self.model,
            max_tokens=1024,
            system=system_prompt,
            tools=_anthropic_tool_schemas(),
            messages=messages,
        )
        tool_calls = [
            {"id": b.id, "name": b.name, "args": b.input}
            for b in response.content if b.type == "tool_use"
        ]
        text = "".join(b.text for b in response.content if b.type == "text")
        assistant_message = {"role": "assistant", "content": response.content}
        return assistant_message, tool_calls, (text or None if not tool_calls else None)

    def format_tool_results(self, results):
        """results: list of (tool_call_id, result_dict) -> one 'user' message."""
        return {
            "role": "user",
            "content": [
                {"type": "tool_result", "tool_use_id": call_id, "content": json.dumps(result)}
                for call_id, result in results
            ],
        }


class OpenAICompatAdapter:
    """OpenAI-compatible chat completions — used for both real OpenAI and
    NVIDIA NIM (NIM exposes an OpenAI-compatible /v1/chat/completions
    endpoint at a different base_url)."""

    def __init__(self, api_key: str, model: str, base_url: str = None):
        from openai import OpenAI
        kwargs = {"api_key": api_key}
        if base_url:
            kwargs["base_url"] = base_url
        self.client = OpenAI(**kwargs)
        self.model = model

    def call(self, messages, system_prompt):
        full_messages = [{"role": "system", "content": system_prompt}] + messages
        response = self.client.chat.completions.create(
            model=self.model,
            max_tokens=1024,
            tools=_openai_tool_schemas(),
            messages=full_messages,
        )
        choice = response.choices[0]
        msg = choice.message
        tool_calls = []
        if msg.tool_calls:
            for tc in msg.tool_calls:
                try:
                    args = json.loads(tc.function.arguments) if tc.function.arguments else {}
                except json.JSONDecodeError:
                    args = {"_parse_error": tc.function.arguments}
                tool_calls.append({"id": tc.id, "name": tc.function.name, "args": args})
        assistant_message = {
            "role": "assistant",
            "content": msg.content or "",
            "tool_calls": [
                {"id": tc.id, "type": "function", "function": {"name": tc.function.name, "arguments": tc.function.arguments}}
                for tc in (msg.tool_calls or [])
            ] or None,
        }
        # OpenAI SDK rejects a null tool_calls key on messages that don't have any
        if not assistant_message["tool_calls"]:
            del assistant_message["tool_calls"]
        text = msg.content if not tool_calls else None
        return assistant_message, tool_calls, text

    def format_tool_results(self, results):
        """OpenAI expects one 'tool' role message PER result, not a batch."""
        return [
            {"role": "tool", "tool_call_id": call_id, "content": json.dumps(result)}
            for call_id, result in results
        ]


NIM_BASE_URL = "https://integrate.api.nvidia.com/v1"


def _build_adapter(provider: str, api_key: str, model: str):
    if not api_key:
        raise ValueError("No API key configured. Add one in Settings → AI Assistant.")
    if provider == "anthropic":
        return AnthropicAdapter(api_key, model)
    elif provider == "openai":
        return OpenAICompatAdapter(api_key, model)
    elif provider == "nim":
        return OpenAICompatAdapter(api_key, model, base_url=NIM_BASE_URL)
    else:
        raise ValueError(f"Unknown provider '{provider}'")


# ── The agent loop (provider-agnostic) ──────────────────────────────

def run_agent_command(user_message: str) -> dict:
    """Runs the full find-then-act agent loop for one user command.
    Returns {"response": str, "actions_taken": [str, ...]}."""
    settings = ai_settings.get_settings_raw()
    provider = settings["provider"]
    api_key = settings["api_key"]
    model = settings["model"] or ai_settings.DEFAULT_MODELS.get(provider, "")

    try:
        adapter = _build_adapter(provider, api_key, model)
    except ValueError as e:
        return {"response": str(e), "actions_taken": []}

    system_prompt = _build_system_prompt()
    messages = [{"role": "user", "content": user_message}]
    actions_taken = []
    final_text = "I wasn't able to complete that — please try rephrasing."

    for _ in range(MAX_AGENT_TURNS):
        try:
            assistant_message, tool_calls, text = adapter.call(messages, system_prompt)
        except Exception as e:
            return {"response": f"AI request failed: {e}", "actions_taken": actions_taken}

        messages.append(assistant_message)

        if not tool_calls:
            final_text = text or final_text
            break

        results = []
        for call in tool_calls:
            result = execute_tool(call["name"], call["args"])
            results.append((call["id"], result))
            if result.get("ok"):
                actions_taken.append(_describe_action(call["name"], result))

        tool_result_message = adapter.format_tool_results(results)
        if isinstance(tool_result_message, list):
            messages.extend(tool_result_message)
        else:
            messages.append(tool_result_message)
    else:
        final_text = "That command needed more steps than I'm allowed to take at once — try breaking it into smaller requests."

    return {"response": final_text, "actions_taken": actions_taken}


def _describe_action(tool_name: str, result: dict) -> str:
    if tool_name == "create_chapter":
        return f"Added '{result.get('name', '?')}' to {result.get('subject', '?')}"
    if tool_name == "update_chapter_status":
        return f"Marked {result.get('name', 'chapter')} as {result.get('new_status', '?')}"
    if tool_name == "update_chapter_details":
        changed = ", ".join(f"{k}={v}" for k, v in result.get("updated", {}).items())
        return f"Updated {result.get('name', 'chapter')} ({changed})"
    if tool_name == "create_exam":
        return f"Created exam '{result.get('name', '?')}'"
    if tool_name == "link_chapter_to_exam":
        return f"Linked {result.get('chapter_name', '?')} to '{result.get('exam_name', '?')}'"
    if tool_name == "mark_exam_completed":
        return f"Marked exam '{result.get('name', '?')}' as completed"
    if tool_name == "create_goal":
        return f"Created goal '{result.get('title', '?')}'"
    if tool_name == "toggle_resource":
        state = "done" if result.get("is_done") else "not done"
        return f"Marked {result.get('label', 'resource')} as {state}"
    return f"Ran {tool_name}"
