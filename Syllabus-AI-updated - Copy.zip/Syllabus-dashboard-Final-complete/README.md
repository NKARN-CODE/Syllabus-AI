# Syllabus Academic Command Center

A self-hosted, multi-page academic dashboard for your Class 10
syllabus: a Dashboard, an All Chapters browser, a full Exams system,
a dedicated Add section, and long-term Analytics — all backed by real
data, with an XP/rank/achievement layer on top.

Notion is used **once**, to import your syllabus. After that, this app
owns the data completely — you stop updating Notion for this purpose.

**Honest by design:** every stat, chart, and countdown is computed
from your actual chapter/exam data. Nothing is decorative. A few
widgets (study streak, recent activity, the daily heatmap, weekly
trend) depend on a real activity log that starts recording the day
you set this up — they'll look sparse at first and fill in as you
use the app, rather than being padded with fake history.

## Pages

- **Dashboard** — completion ring, streak, subject progress, upcoming
  exam countdowns, weakest subjects, what-to-study-next, recent
  activity feed, daily activity heatmap, weekly trend
- **All Chapters** — every chapter across every subject, grouped,
  searchable, filterable (subject/status/priority), sortable. Each row
  has a fast 4-button checklist (Not started / Practice / Revision
  needed / Completed) that updates instantly, no modal — plus a
  resource progress bar ("4/7 done"). Click a row to open the full
  editor and its resource checklist.
- **Exams** — exam cards with real countdown + prep readiness computed
  from linked chapters; add/edit/delete; assign chapters to an exam
- **Resources** — every resource type (Textbook, Tuition 1, Tuition 1
  Olympiad, Big Question Bank, Question Bank, Tuition 2, DPPs), ranked
  by fixed importance, showing exactly which chapters still need that
  resource done. Nothing to configure — resources are attached
  automatically based on each chapter's subject.
- **Add** — one clear action per data type: chapter, subject, exam,
  study session, goal
- **Analytics** — bigger versions of the same real charts, plus goals
  with computed progress where the goal type supports it
- **Settings** — what's real vs. what fills in over time, and where
  your data lives

---

## How it works

One Python server (FastAPI) does three things at once:
1. Serves the API (`/api/...`)
2. Serves the dashboard itself (plain HTML/JS/CSS, no build step)
3. Optionally opens as a native desktop window (via `desktop.py`)

Your phone reaches the exact same server over your home wifi — no
app to install, no account, no cloud hosting. Just a browser tab
pointed at your PC's local IP.

---

## One-click launch (Windows)

Double-click **`Run_Dashboard.bat`** in the project root. That's it.

- First run: sets up a virtual environment, installs dependencies, and
  imports your syllabus from `data/notion_export.json` — takes 30–60
  seconds.
- Every run after that: opens instantly as a native window on this PC.
  Your phone can open the same dashboard at the LAN address printed in
  the terminal window (same wifi, no app to install).

Skip to "Using it day to day" below once it's open. Everything past
this point is for manual/non-Windows setup.

---

## One-time setup

```bash
cd backend
pip install -r ../requirements.txt   # or: pip install fastapi uvicorn pydantic pywebview

python import_notion.py ../data/notion_export.json
```

This reads your syllabus data, merges duplicate chapters (e.g. the
same chapter tracked for both Boards and AITS), flags placeholder
rows, and builds `syllabus.db` — a local SQLite file. Do this once.
Re-running it will re-import from the same JSON file, so only do
this again if you want to reset from scratch.

**Note:** `data/notion_export.json` contains a snapshot of your Notion
syllabus tracker as it stood during planning. If your real Notion has
changed since, you'll want a fresh export before running the import —
ask for a re-pull if so, since this file will go stale otherwise.

---

## Running it

**Option A — browser only** (simplest):
```bash
cd backend
python main.py
```
Then open `http://localhost:8000` on this PC.

**Option B — desktop window + phone access** (what you asked for):
```bash
cd backend
python desktop.py
```
This opens a native window on your PC **and** keeps the same server
listening on your network, so your phone can open
`http://<this-pc-lan-ip>:8000` in its browser at the same time. The
LAN IP is printed in the terminal when it starts.

Both your phone and PC are talking to the *same* server and the *same*
database — that's the "sync," and it's instant, because there's only
ever one copy of the data.

---

## Using it day to day

- **Three columns**: Urgent (deadline-sorted), Highest ROI
  (priority × exam reach ÷ effort), Maintain (settled, not urgent).
- **Tap any chapter** to open its detail view — every field is now
  editable: name, subject, board scope, status, priority, effort,
  and free-text notes. This is now the only place you update your
  syllabus; Notion is no longer touched.
- **"+ Add chapter"** (top right) creates a brand-new chapter from
  scratch — for when a topic gets added mid-year. It opens straight
  into edit mode afterward so you can link exam targets immediately.
- **Delete a chapter** from its detail view (asks for confirmation
  first — this can't be undone).
- **Exam targets are editable too**, from inside a chapter's detail
  view: link an existing target with an optional chapter-specific
  deadline, unlink one, or create a brand-new target (e.g. a newly
  announced test) and link it in the same step.
- **XP happens automatically.** Moving a chapter's status forward, and
  especially reaching "Tested," earns XP and can unlock achievements —
  no separate logging required, it's a side effect of using the
  dashboard normally.
- **Rank and XP bar** shown top-right on desktop (hidden on narrow
  phone screens to save space). **Achievement strip** along the bottom
  shows locked/unlocked badges.

---

## What's deliberately NOT in this app

Per the design decisions made while planning this:
- No study log / session history (no decay or spacing calculations)
- No daily plan generator (no "today's picks")
- No maintenance duration tracking (Maintain is a static list, not a
  countdown)
- No bias tracker, identity log, recognition events, or experiments
  from the Research Tracker — those were specific to that 6-month
  program and don't map onto a syllabus.

If you want any of these back later, say so — each was cut
deliberately, not forgotten.

---

## File structure

```
syllabus-app/
├── Run_Dashboard.bat   — one-click launcher (Windows)
├── backend/
│   ├── main.py           — FastAPI app, all API routes
│   ├── db.py              — SQLite schema + fixed scoring constants
│   ├── scoring.py          — the three-question thinking system
│   ├── gamification.py     — XP, ranks, achievements
│   ├── import_notion.py    — one-time Notion import with dedup rules
│   └── desktop.py          — pywebview wrapper (native window + LAN)
├── frontend/
│   ├── index.html
│   ├── style.css
│   └── app.js
├── data/
│   └── notion_export.json  — your syllabus snapshot (see note above)
└── requirements.txt
```

---

## How the resource system works

Every chapter in Physics, Chemistry, Biology, Maths, English, Social
Science, and Mental Ability automatically gets the resources that apply
to its subject — you never create or configure a resource yourself,
only check it off. Importance is fixed, not something you set per item:

```
Textbook  >  Tuition 1 (+ Olympiad, just after)  >  Big Question Bank
>  Question Bank  >  Tuition 2  >  DPPs
```

Big Question Bank only exists for Science subjects and Social Science.
Olympiad Maths/Science use the exact same chapters as regular Tuition 1,
just harder material — no separate chapter list. AI and Sanskrit were
never part of this resource breakdown, so they're intentionally left
out — they still track status/priority exactly as before.

A one-time cleanup (`backend/migrate_cleanup.py`) already ran against
your data: it merged 14 Maths chapters that had been duplicated as
separate "Scholarship — X" rows (Maths went from 30 rows down to the
real 14 + 1 placeholder), did the same for Science, and split "Science"
into real Physics/Chemistry/Biology subjects. Three chapters — Control
and Coordination, Electricity, Heredity — only ever existed as
"Scholarship — X" rows with no plain counterpart, so they were promoted
to real chapters rather than discarded.

**Known incomplete area:** Social Science only has 7 chapters (Geography
and Economics topics) — no History or Political Science/Civics chapters
were found anywhere in the original data. That's flagged as a
placeholder chapter rather than invented; add the real ones via the Add
page once you have the list.

---

## Known data quirks (carried over from Notion, worth knowing)

- A few `Finish By` dates are already in the past as of import — these
  correctly show as "overdue" in Urgent rather than being hidden.
  That's real information, not a bug: it means those chapters were
  due before the app was even set up, so decide whether they're still
  relevant.
- 4 chapters are flagged as placeholders (e.g. "Maths — add
  chapters") and excluded from all scoring until you replace them with
  real chapter entries.
