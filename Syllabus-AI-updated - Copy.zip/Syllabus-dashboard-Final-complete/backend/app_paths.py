"""
Path resolution that works correctly both in normal development (running
`python main.py` directly) and when frozen into a single .exe by
PyInstaller.

Two DIFFERENT kinds of paths need two DIFFERENT answers here, and mixing
them up is the single most common way this kind of app breaks after being
frozen:

  - bundled_path(...)   — read-only assets shipped WITH the app (the
    frontend's index.html/app.js/style.css). These are fine to live
    inside PyInstaller's temp extraction folder (sys._MEIPASS), because
    they never change at runtime and get re-extracted fresh every launch.

  - persistent_data_dir() — the user's actual, growing, precious data
    (syllabus.db, and anything else that must survive between runs and
    between app updates). This must NEVER live inside sys._MEIPASS —
    that folder is wiped and recreated on every single launch, so a
    database placed there would silently lose all data the moment the
    app closes. It lives in the OS's real per-user app-data folder
    instead, exactly like every other well-behaved Windows app.
"""
import os
import sys


def is_frozen() -> bool:
    """True only inside a PyInstaller-built .exe, never in normal
    `python main.py` development."""
    return getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS")


def bundled_path(*parts) -> str:
    """Resolve a path to a read-only asset shipped with the app (e.g. the
    frontend folder). Safe for anything that's never written to."""
    if is_frozen():
        base = sys._MEIPASS
    else:
        # Matches the existing dev-mode layout: backend/ is a sibling of
        # frontend/, so going one level up from this file's directory
        # lands at the project root.
        base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, *parts)


def persistent_data_dir() -> str:
    """Resolve (and create if missing) a stable, writable folder for the
    user's real data, outside any PyInstaller temp bundle. Survives
    between runs and between app updates."""
    if is_frozen():
        # %LOCALAPPDATA%\SyllabusDashboard on Windows — the same place
        # any normal installed Windows app keeps its user data.
        base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
        data_dir = os.path.join(base, "SyllabusDashboard")
    else:
        # Dev mode: keep using the existing location (backend/ folder
        # itself) so nothing changes for anyone running from source.
        data_dir = os.path.dirname(os.path.abspath(__file__))
    os.makedirs(data_dir, exist_ok=True)
    return data_dir


def persistent_path(*parts) -> str:
    """Resolve a path inside the persistent data directory, creating the
    directory if it doesn't exist yet."""
    return os.path.join(persistent_data_dir(), *parts)
