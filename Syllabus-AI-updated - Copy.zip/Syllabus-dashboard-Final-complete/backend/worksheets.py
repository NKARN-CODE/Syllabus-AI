"""
Retrieval worksheets — up to 10 PDF worksheets per chapter, each used
exactly once, drawn in order on a schedule that adapts based on how the
previous one scored.

Scheduling rule, applied when a worksheet is scored and the next one
(if any) gets its scheduled_date set:
  - score >= WORKSHEET_GOOD_SCORE  -> next interval = last interval * WORKSHEET_GOOD_MULTIPLIER
  - score <  WORKSHEET_BAD_SCORE   -> next interval = WORKSHEET_BAD_RESET_DAYS (a reset, not a shrink)
  - otherwise                       -> next interval = same as last interval

The very first worksheet of a chapter (no prior score to adapt from) is
scheduled WORKSHEET_FIRST_INTERVAL_DAYS after the chapter is marked
completed.

Interval math is anchored to when the PRIOR worksheet was scheduled to
happen, not to when it was actually completed — so completing a
worksheet late doesn't silently compress the next gap.
"""
import os
from datetime import date, datetime, timedelta

from db import (
    get_conn,
    WORKSHEET_FIRST_INTERVAL_DAYS,
    WORKSHEET_GOOD_SCORE,
    WORKSHEET_BAD_SCORE,
    WORKSHEET_GOOD_MULTIPLIER,
    WORKSHEET_BAD_RESET_DAYS,
    WORKSHEET_MAX_SLOTS,
)

from app_paths import persistent_path

UPLOAD_DIR = persistent_path("uploads", "worksheets")


def _ensure_upload_dir():
    os.makedirs(UPLOAD_DIR, exist_ok=True)


def _today():
    return date.today().isoformat()


def _add_days(iso_date: str, days: float) -> str:
    d = datetime.fromisoformat(iso_date).date()
    return (d + timedelta(days=days)).isoformat()


# ── Upload ────────────────────────────────────────────────────────

def next_open_slot(chapter_id: int):
    """Returns the lowest unused slot_number (1..10) for this chapter,
    or None if all 10 are taken."""
    with get_conn() as conn:
        used = {r["slot_number"] for r in conn.execute(
            "SELECT slot_number FROM worksheet WHERE chapter_id = ?", (chapter_id,)
        ).fetchall()}
    for slot in range(1, WORKSHEET_MAX_SLOTS + 1):
        if slot not in used:
            return slot
    return None


def save_worksheet_file(chapter_id: int, original_filename: str, file_bytes: bytes):
    """Writes the PDF to disk and creates its worksheet row in the next
    open slot. Returns the new row as a dict, or raises ValueError if
    the chapter already has all 10 slots filled."""
    slot = next_open_slot(chapter_id)
    if slot is None:
        raise ValueError(f"Chapter {chapter_id} already has all {WORKSHEET_MAX_SLOTS} worksheet slots filled.")

    _ensure_upload_dir()
    safe_name = f"chapter{chapter_id}_slot{slot}.pdf"
    file_path = os.path.join(UPLOAD_DIR, safe_name)
    with open(file_path, "wb") as f:
        f.write(file_bytes)

    with get_conn() as conn:
        cur = conn.execute(
            """INSERT INTO worksheet (chapter_id, slot_number, file_path, original_filename, uploaded_at, status)
               VALUES (?, ?, ?, ?, ?, 'pending')""",
            (chapter_id, slot, file_path, original_filename, datetime.now().isoformat()),
        )
        worksheet_id = cur.lastrowid

    # If this chapter is already marked completed and nothing is scheduled
    # yet, this upload might be the one that kicks off the schedule.
    _maybe_schedule_first(chapter_id)

    return get_worksheet(worksheet_id)


def get_worksheet(worksheet_id: int):
    with get_conn() as conn:
        row = conn.execute("SELECT * FROM worksheet WHERE id = ?", (worksheet_id,)).fetchone()
    return dict(row) if row else None


def list_worksheets_for_chapter(chapter_id: int):
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM worksheet WHERE chapter_id = ? ORDER BY slot_number", (chapter_id,)
        ).fetchall()
    return [dict(r) for r in rows]


# ── Scheduling triggers ──────────────────────────────────────────

def _maybe_schedule_first(chapter_id: int):
    """Call this whenever a chapter's status changes to completed, AND
    whenever a new worksheet is uploaded — either event might be the one
    that makes 'chapter is completed AND has an unscheduled worksheet #1'
    become true for the first time."""
    with get_conn() as conn:
        chapter = conn.execute("SELECT status FROM chapter WHERE id = ?", (chapter_id,)).fetchone()
        if not chapter or chapter["status"] != "Tested":
            return False

        already_scheduled_or_done = conn.execute(
            "SELECT COUNT(*) as n FROM worksheet WHERE chapter_id = ? AND status IN ('scheduled', 'done')",
            (chapter_id,),
        ).fetchone()["n"]
        if already_scheduled_or_done > 0:
            return False  # a schedule is already running for this chapter

        first = conn.execute(
            "SELECT id FROM worksheet WHERE chapter_id = ? AND slot_number = 1 AND status = 'pending'",
            (chapter_id,),
        ).fetchone()
        if not first:
            return False  # worksheet #1 hasn't been uploaded yet

        scheduled_date = _add_days(_today(), WORKSHEET_FIRST_INTERVAL_DAYS)
        conn.execute(
            "UPDATE worksheet SET status = 'scheduled', scheduled_date = ?, interval_days = ? WHERE id = ?",
            (scheduled_date, WORKSHEET_FIRST_INTERVAL_DAYS, first["id"]),
        )
    return True


def on_chapter_marked_completed(chapter_id: int):
    """Call this from the chapter status-update path whenever a chapter's
    status becomes 'Tested'. Safe to call even if no worksheets exist yet
    or a schedule is already running — it's a no-op in those cases."""
    return _maybe_schedule_first(chapter_id)


# ── Scoring and rescheduling ─────────────────────────────────────

def submit_score(worksheet_id: int, score_pct: float):
    """Records a score for a scheduled worksheet, marks it done, and
    schedules the next slot (if one exists and is still pending)."""
    if not (0 <= score_pct <= 100):
        raise ValueError("score_pct must be between 0 and 100")

    with get_conn() as conn:
        ws = conn.execute("SELECT * FROM worksheet WHERE id = ?", (worksheet_id,)).fetchone()
        if not ws:
            raise ValueError(f"No worksheet with id {worksheet_id}")
        if ws["status"] != "scheduled":
            raise ValueError(f"Worksheet {worksheet_id} is not currently scheduled (status: {ws['status']})")

        conn.execute(
            "UPDATE worksheet SET status = 'done', completed_date = ?, score_pct = ? WHERE id = ?",
            (_today(), score_pct, worksheet_id),
        )

        chapter_id = ws["chapter_id"]
        last_interval = ws["interval_days"] or WORKSHEET_FIRST_INTERVAL_DAYS
        last_scheduled_date = ws["scheduled_date"] or _today()

        if score_pct >= WORKSHEET_GOOD_SCORE:
            next_interval = last_interval * WORKSHEET_GOOD_MULTIPLIER
        elif score_pct < WORKSHEET_BAD_SCORE:
            next_interval = WORKSHEET_BAD_RESET_DAYS
        else:
            next_interval = last_interval

        next_slot = conn.execute(
            "SELECT id FROM worksheet WHERE chapter_id = ? AND slot_number = ? AND status = 'pending'",
            (chapter_id, ws["slot_number"] + 1),
        ).fetchone()

        next_scheduled_date = None
        if next_slot:
            # Anchored to when THIS worksheet was due, not when it was
            # actually completed — a late completion doesn't compress
            # the next gap.
            next_scheduled_date = _add_days(last_scheduled_date, next_interval)
            conn.execute(
                "UPDATE worksheet SET status = 'scheduled', scheduled_date = ?, interval_days = ? WHERE id = ?",
                (next_scheduled_date, next_interval, next_slot["id"]),
            )

    return {
        "worksheet_id": worksheet_id,
        "score_pct": score_pct,
        "next_worksheet_scheduled": bool(next_slot),
        "next_scheduled_date": next_scheduled_date,
        "chapter_complete": next_slot is None,
    }


# ── Dashboard / list views ───────────────────────────────────────

def list_due(include_overdue_only=False):
    """All worksheets that are scheduled and due today or earlier,
    joined with their chapter's name/subject for display."""
    today = _today()
    with get_conn() as conn:
        rows = conn.execute(
            """SELECT worksheet.*, chapter.name as chapter_name, chapter.subject as chapter_subject
               FROM worksheet JOIN chapter ON chapter.id = worksheet.chapter_id
               WHERE worksheet.status = 'scheduled' AND worksheet.scheduled_date <= ?
               ORDER BY worksheet.scheduled_date""",
            (today,),
        ).fetchall()
    return [dict(r) for r in rows]


def list_upcoming(limit=20):
    """Scheduled worksheets not yet due, soonest first — for a dashboard
    preview of what's coming."""
    today = _today()
    with get_conn() as conn:
        rows = conn.execute(
            """SELECT worksheet.*, chapter.name as chapter_name, chapter.subject as chapter_subject
               FROM worksheet JOIN chapter ON chapter.id = worksheet.chapter_id
               WHERE worksheet.status = 'scheduled' AND worksheet.scheduled_date > ?
               ORDER BY worksheet.scheduled_date LIMIT ?""",
            (today, limit),
        ).fetchall()
    return [dict(r) for r in rows]


def stats():
    """Real numbers for the dashboard widget — every figure here is
    computed from actual worksheet rows, nothing decorative."""
    today = _today()
    with get_conn() as conn:
        due_today = conn.execute(
            "SELECT COUNT(*) as n FROM worksheet WHERE status = 'scheduled' AND scheduled_date = ?", (today,)
        ).fetchone()["n"]
        overdue = conn.execute(
            "SELECT COUNT(*) as n FROM worksheet WHERE status = 'scheduled' AND scheduled_date < ?", (today,)
        ).fetchone()["n"]
        upcoming_7d = conn.execute(
            "SELECT COUNT(*) as n FROM worksheet WHERE status = 'scheduled' AND scheduled_date > ? AND scheduled_date <= ?",
            (today, _add_days(today, 7)),
        ).fetchone()["n"]
        done_count = conn.execute("SELECT COUNT(*) as n FROM worksheet WHERE status = 'done'").fetchone()["n"]
        avg_score_row = conn.execute("SELECT AVG(score_pct) as avg FROM worksheet WHERE status = 'done'").fetchone()
        avg_score = round(avg_score_row["avg"], 1) if avg_score_row["avg"] is not None else None
        active_chapters = conn.execute(
            "SELECT COUNT(DISTINCT chapter_id) as n FROM worksheet WHERE status IN ('scheduled', 'done')"
        ).fetchone()["n"]
        good_count = conn.execute(
            "SELECT COUNT(*) as n FROM worksheet WHERE status = 'done' AND score_pct >= ?", (WORKSHEET_GOOD_SCORE,)
        ).fetchone()["n"]
        bad_count = conn.execute(
            "SELECT COUNT(*) as n FROM worksheet WHERE status = 'done' AND score_pct < ?", (WORKSHEET_BAD_SCORE,)
        ).fetchone()["n"]

    return {
        "due_today": due_today,
        "overdue": overdue,
        "upcoming_7d": upcoming_7d,
        "completed_total": done_count,
        "average_score": avg_score,
        "active_chapters": active_chapters,
        "good_count": good_count,
        "bad_count": bad_count,
    }
