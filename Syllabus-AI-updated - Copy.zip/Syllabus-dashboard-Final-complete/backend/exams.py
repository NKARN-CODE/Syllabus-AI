"""
Exams as a first-class entity: name, date, time, priority, notes,
completion state, plus computed prep readiness from the chapters
linked to it via chapter_target. Readiness is real: (# linked chapters
at Tested or First pass done) / (# linked chapters) — not a guess.
"""
from datetime import date, datetime
from db import get_conn


def _parse_date(s):
    if not s:
        return None
    try:
        return datetime.strptime(s, "%Y-%m-%d").date()
    except ValueError:
        return None


def list_exams():
    with get_conn() as conn:
        exams = conn.execute("SELECT * FROM exam_target").fetchall()
        result = []
        today = date.today()
        for e in exams:
            chapters = conn.execute(
                """SELECT c.id, c.name, c.subject, c.status, ct.finish_by
                   FROM chapter_target ct JOIN chapter c ON c.id = ct.chapter_id
                   WHERE ct.exam_target_id = ? AND c.is_placeholder = 0""",
                (e["id"],),
            ).fetchall()
            total = len(chapters)
            ready = sum(1 for c in chapters if c["status"] in ("Tested", "First pass done"))

            # The exam_target's own `date` field is authoritative when set.
            # Many real exams (Boards, AITS, Scholarship...) were imported
            # without one, though — the actual deadline only ever lived on
            # the linked chapters' `finish_by`. Falling back to the earliest
            # of those is real data, not a guess, and it's what was silently
            # missing before: every real exam showed no countdown at all.
            d = _parse_date(e["date"])
            if d is None:
                chapter_dates = [cd for cd in (_parse_date(c["finish_by"]) for c in chapters) if cd is not None]
                if chapter_dates:
                    d = min(chapter_dates)
            days_left = (d - today).days if d else None

            result.append({
                **dict(e),
                "chapters": [dict(c) for c in chapters],
                "chapters_total": total,
                "chapters_ready": ready,
                "readiness_pct": round(100 * ready / total, 1) if total else 0,
                "days_left": days_left,
                "effective_date": d.isoformat() if d else None,
                "is_overdue": days_left is not None and days_left < 0 and not e["is_completed"],
            })

        # Sort by the effective countdown (real or fallback), not just the
        # exam_target's own raw date column — undated-but-linked exams now
        # sort correctly among the ones with an explicit date.
        result.sort(key=lambda r: r["days_left"] if r["days_left"] is not None else 999999)
        return result


def create_exam(name, date_, time_, priority, notes, exam_type="Other"):
    with get_conn() as conn:
        existing = conn.execute("SELECT id FROM exam_target WHERE name = ?", (name,)).fetchone()
        if existing:
            return None  # caller checks for None -> 409
        cur = conn.execute(
            "INSERT INTO exam_target (name, date, time, priority, notes, exam_type) VALUES (?, ?, ?, ?, ?, ?)",
            (name, date_, time_, priority, notes, exam_type),
        )
        return cur.lastrowid


def update_exam(exam_id, fields: dict):
    if not fields:
        return False
    with get_conn() as conn:
        set_clause = ", ".join(f"{k} = ?" for k in fields)
        values = list(fields.values()) + [exam_id]
        cur = conn.execute(f"UPDATE exam_target SET {set_clause} WHERE id = ?", values)
        return cur.rowcount > 0


def delete_exam(exam_id):
    with get_conn() as conn:
        cur = conn.execute("DELETE FROM exam_target WHERE id = ?", (exam_id,))
        return cur.rowcount > 0


def link_chapter(exam_id, chapter_id, finish_by=None):
    with get_conn() as conn:
        conn.execute(
            """INSERT OR REPLACE INTO chapter_target (chapter_id, exam_target_id, finish_by)
               VALUES (?, ?, ?)""",
            (chapter_id, exam_id, finish_by),
        )


def unlink_chapter(exam_id, chapter_id):
    with get_conn() as conn:
        cur = conn.execute(
            "DELETE FROM chapter_target WHERE exam_target_id = ? AND chapter_id = ?",
            (exam_id, chapter_id),
        )
        return cur.rowcount > 0
