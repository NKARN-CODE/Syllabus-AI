"""
Database layer for the Syllabus Thinking Dashboard.
Single SQLite file, no ORM — plain sqlite3 with explicit SQL so the
scoring logic (which needs custom joins/aggregation) stays transparent.
"""
import sqlite3
import os
from contextlib import contextmanager
from app_paths import persistent_path

DB_PATH = persistent_path("syllabus.db")

SCHEMA = """
CREATE TABLE IF NOT EXISTS chapter (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    subject TEXT NOT NULL,
    name TEXT NOT NULL,
    board_scope TEXT NOT NULL DEFAULT 'None',
    status TEXT NOT NULL DEFAULT 'Not started',
    priority TEXT NOT NULL DEFAULT 'Should',
    effort_weight INTEGER NOT NULL DEFAULT 3,
    difficulty TEXT NOT NULL DEFAULT 'Medium',   -- Easy | Medium | Hard, user-set
    is_placeholder INTEGER NOT NULL DEFAULT 0,
    notes TEXT DEFAULT '',
    last_studied TEXT                             -- ISO date, set automatically on any edit
);

CREATE TABLE IF NOT EXISTS exam_target (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    date TEXT,
    time TEXT,                                    -- "HH:MM", optional
    priority TEXT NOT NULL DEFAULT 'Should',      -- Must | Should | Later
    notes TEXT DEFAULT '',
    is_completed INTEGER NOT NULL DEFAULT 0,      -- manually marked done
    exam_type TEXT DEFAULT 'Other'                 -- Board | Preboard | Mock Test | Scholarship | Competition | Class Test | Other
);

CREATE TABLE IF NOT EXISTS chapter_target (
    chapter_id INTEGER NOT NULL REFERENCES chapter(id) ON DELETE CASCADE,
    exam_target_id INTEGER NOT NULL REFERENCES exam_target(id) ON DELETE CASCADE,
    finish_by TEXT,
    PRIMARY KEY (chapter_id, exam_target_id)
);

-- Real, timestamped record of every meaningful action. Nothing here is
-- backfilled or synthetic — it starts recording from whenever this
-- schema version first runs, so streak/heatmap/trend widgets are honest
-- about being sparse at first and filling in as the app gets used.
CREATE TABLE IF NOT EXISTS activity_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chapter_id INTEGER REFERENCES chapter(id) ON DELETE SET NULL,
    timestamp TEXT NOT NULL,                      -- ISO datetime
    action TEXT NOT NULL,                         -- created | status_change | study_session
    from_status TEXT,
    to_status TEXT,
    note TEXT DEFAULT ''
);

CREATE TABLE IF NOT EXISTS goal (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    target_type TEXT NOT NULL DEFAULT 'custom',   -- chapters_tested | subject_complete | custom
    subject TEXT,
    target_value INTEGER,
    target_date TEXT,
    created_at TEXT NOT NULL,
    is_completed INTEGER NOT NULL DEFAULT 0
);

-- One row per (chapter, resource type) — e.g. "Tuition 1" on chapter
-- "Real Numbers". Binary done/not-done only, per the checklist model.
-- resource_key values and their fixed importance rank live in
-- resources.py (RESOURCE_TYPES), not in this table — the ranking is
-- fixed by design, not something the user configures per-resource.
CREATE TABLE IF NOT EXISTS chapter_resource (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chapter_id INTEGER NOT NULL REFERENCES chapter(id) ON DELETE CASCADE,
    resource_key TEXT NOT NULL,
    is_done INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL,
    UNIQUE(chapter_id, resource_key)
);

-- Single-row settings for the AI agent: which provider/key/model to use.
-- id is pinned to 1 by the CHECK constraint since this is a single-user
-- app with exactly one active AI configuration at a time.
CREATE TABLE IF NOT EXISTS ai_settings (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    provider TEXT NOT NULL DEFAULT 'anthropic',   -- anthropic | openai | nim
    api_key TEXT NOT NULL DEFAULT '',
    model TEXT NOT NULL DEFAULT ''
);

-- Retrieval worksheets: up to 10 fixed PDF slots per chapter, each used
-- exactly once (never recycled). slot_number is the fixed order they're
-- drawn in. status moves pending -> scheduled -> done as the retrieval
-- system progresses; only one worksheet per chapter is ever 'scheduled'
-- at a time, the rest sit 'pending' until their turn.
CREATE TABLE IF NOT EXISTS worksheet (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chapter_id INTEGER NOT NULL REFERENCES chapter(id) ON DELETE CASCADE,
    slot_number INTEGER NOT NULL,
    file_path TEXT NOT NULL,
    original_filename TEXT,
    uploaded_at TEXT NOT NULL,
    scheduled_date TEXT,
    completed_date TEXT,
    score_pct REAL,
    status TEXT NOT NULL DEFAULT 'pending',       -- pending | scheduled | done
    interval_days REAL,                            -- the gap used to schedule THIS worksheet, for computing the next one
    UNIQUE(chapter_id, slot_number)
);
"""

# Fixed weight constants — locked in during design, not user-editable via API.
PRIORITY_WEIGHT = {"Must": 3, "Should": 2, "Later": 1}
BOARD_SCOPE_WEIGHT = {"Both": 1.0, "Boards": 0.7, "Preboard": 0.7, "None": 0.4}
REVISION_PENALTY = 1.2  # multiplier applied to effort when status == "Needs revision"
URGENT_WINDOW_DAYS = 7  # red-flag threshold

# Retrieval worksheet scheduling — see worksheets.py for the actual logic.
WORKSHEET_FIRST_INTERVAL_DAYS = 8      # first worksheet: scheduled_date = completion + 8 days
WORKSHEET_GOOD_SCORE = 80              # >= this % -> interval grows
WORKSHEET_BAD_SCORE = 20               # < this % -> interval resets short
WORKSHEET_GOOD_MULTIPLIER = 1.5        # growth factor on a good score
WORKSHEET_BAD_RESET_DAYS = 3           # fixed short interval on a bad score
WORKSHEET_MAX_SLOTS = 10

# The 4-option fast checklist maps onto the existing 6-value status field —
# no new column, no scoring-logic change. "Not started yet" and "Completed"
# reuse the exact existing values; "Practice" and "Revision needed" do too.
# The full 6-value set stays available in the detail view for finer control.
QUICK_STATUS_MAP = {
    "not_started": "Not started",
    "practice": "Practice",
    "revision": "Needs revision",
    "completed": "Tested",
}


@contextmanager
def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def _migrate_existing_tables(conn):
    """
    Adds new columns to tables that may already exist from a previous
    version of this app (ALTER TABLE ADD COLUMN, one at a time, ignoring
    "duplicate column" errors so this is safe to run on every startup).
    """
    migrations = [
        ("chapter", "difficulty", "TEXT NOT NULL DEFAULT 'Medium'"),
        ("chapter", "last_studied", "TEXT"),
        ("chapter", "unit", "TEXT"),               # official syllabus unit name — nullable, only set where actually known
        ("chapter", "weightage_marks", "INTEGER"), # official exam weightage in marks — nullable, only set where actually known
        ("exam_target", "time", "TEXT"),
        ("exam_target", "priority", "TEXT NOT NULL DEFAULT 'Should'"),
        ("exam_target", "notes", "TEXT DEFAULT ''"),
        ("exam_target", "is_completed", "INTEGER NOT NULL DEFAULT 0"),
        ("exam_target", "exam_type", "TEXT DEFAULT 'Other'"),
    ]
    for table, column, coltype in migrations:
        try:
            conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {coltype}")
        except sqlite3.OperationalError as e:
            if "duplicate column" not in str(e).lower():
                raise


def init_db():
    with get_conn() as conn:
        conn.executescript(SCHEMA)
        _migrate_existing_tables(conn)
