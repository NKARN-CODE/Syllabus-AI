"""
One-time addition: the real Social Science syllabus (21 chapters across
4 units, from the official CBSE weightage table) vs. the 7 chapters that
existed in the app (only Geography + a scattered few). This adds the 14
that were missing, using the exact names/units/marks from the source
document — nothing here is invented.

Also removes the "Social Science — add remaining chapters" placeholder
chapter created earlier, since its whole purpose was to flag this gap —
now filled.

Safe to re-run: every insert checks the chapter doesn't already exist
by name before adding it.
"""
from db import get_conn
import resources as resources_mod

# (name, unit, weightage_marks) — exactly as shown in the official
# weightage table. Existing chapters (Print Culture and the Modern
# World, Resources and Development, Water Resources, Agriculture,
# Outcomes of Democracy, Sectors of the Indian Economy, Money and
# Credit) are skipped — they're already in the database.
MISSING_CHAPTERS = [
    # Unit 1: India and the Contemporary World – II (History)
    ("The Rise of Nationalism in Europe", "Unit 1: India and the Contemporary World – II", 5),
    ("Nationalism in India", "Unit 1: India and the Contemporary World – II", 5),
    ("The Making of a Global World", "Unit 1: India and the Contemporary World – II", 3),
    ("The Age of Industrialization", "Unit 1: India and the Contemporary World – II", 4),
    # Unit 2: Contemporary India – II (Geography)
    ("Forest and Wildlife", "Unit 2: Contemporary India – II", 1),
    ("Minerals and Energy Resources", "Unit 2: Contemporary India – II", 3),
    ("Manufacturing Industries", "Unit 2: Contemporary India – II", 6),
    ("Life Lines of National Economy", "Unit 2: Contemporary India – II", 3),
    # Unit 3: Democratic Politics – II (Political Science)
    ("Power Sharing", "Unit 3: Democratic Politics – II", 6),
    ("Federalism", "Unit 3: Democratic Politics – II", 3),
    ("Gender, Religion and Caste", "Unit 3: Democratic Politics – II", 3),
    ("Political Parties", "Unit 3: Democratic Politics – II", 5),
    # Unit 4: Understanding Economic Development (Economics)
    ("Development", "Unit 4: Understanding Economic Development", 2),
    ("Globalization and the Indian Economy", "Unit 4: Understanding Economic Development", 5),
]

# Same pattern the existing 7 Social Science chapters already use.
EXAM_TARGETS_TO_LINK = ["Boards — 2027", "Preboards", "Syllabus completion — Sep"]
FINISH_BY = "2026-09-25"


def run():
    with get_conn() as conn:
        existing = {r["name"] for r in conn.execute("SELECT name FROM chapter WHERE subject = 'Social Science'").fetchall()}
        target_ids = {}
        for tname in EXAM_TARGETS_TO_LINK:
            row = conn.execute("SELECT id FROM exam_target WHERE name = ?", (tname,)).fetchone()
            if row:
                target_ids[tname] = row["id"]

        inserted = []
        for name, unit, marks in MISSING_CHAPTERS:
            if name in existing:
                continue
            cur = conn.execute(
                """INSERT INTO chapter (subject, name, board_scope, status, priority, effort_weight,
                                        difficulty, is_placeholder, notes, unit, weightage_marks)
                   VALUES ('Social Science', ?, 'Both', 'Not started', 'Must', 3, 'Medium', 0, '', ?, ?)""",
                (name, unit, marks),
            )
            chapter_id = cur.lastrowid
            inserted.append((chapter_id, name))
            for tname, tid in target_ids.items():
                conn.execute(
                    "INSERT OR IGNORE INTO chapter_target (chapter_id, exam_target_id, finish_by) VALUES (?, ?, ?)",
                    (chapter_id, tid, FINISH_BY),
                )

        # remove the now-obsolete placeholder
        placeholder = conn.execute(
            "SELECT id FROM chapter WHERE subject = 'Social Science' AND name LIKE 'Social Science — add remaining%'"
        ).fetchone()
        if placeholder:
            conn.execute("DELETE FROM chapter WHERE id = ?", (placeholder["id"],))

    for chapter_id, name in inserted:
        resources_mod.sync_chapter_resources(chapter_id, "Social Science")

    print(f"Inserted {len(inserted)} chapters, removed placeholder: {bool(placeholder)}")


if __name__ == "__main__":
    run()
