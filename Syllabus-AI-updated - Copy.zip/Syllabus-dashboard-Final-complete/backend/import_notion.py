"""
One-time Notion import.

This script does NOT call the Notion API itself — the data was already
pulled via Claude's Notion connector during planning (157 rows from the
"Class 10 Syllabus Tracker" database). Paste that raw export into
RAW_ROWS below (or load from a JSON file — see NOTE at bottom) and run:

    python import_notion.py

Rules applied (locked in during design, see conversation history):
  1. Duplicate chapter rows (same subject+name, different exam target)
     are MERGED into one chapter with multiple targets.
  2. On conflict between merged rows: keep the MOST ADVANCED status
     and the HIGHEST priority.
  3. Placeholder rows ("add chapters", "exact course list", etc.) are
     flagged is_placeholder=1 and excluded from all scoring.
  4. effort_weight defaults to 3 (flat) for every chapter — no guessing
     per subject. Adjust manually in the app afterward.
  5. This import is intended to run ONCE. After this, the app owns the
     data — do not re-run against a stale Notion export, and stop
     updating Notion for this purpose going forward.
"""
import json
import sys
from db import get_conn, init_db

# Status values ordered from least to most advanced, for conflict resolution.
STATUS_ORDER = [
    "Not started", "Learning", "Practice", "Needs revision",
    "First pass done", "Tested",
]
# NOTE: "Needs revision" is ranked ahead of "Not started"/"Learning"/"Practice"
# but behind "First pass done"/"Tested" — it implies real prior progress even
# though it flags a problem. Adjust STATUS_ORDER here if that ordering feels wrong
# once you see it applied to your real data.

PRIORITY_ORDER = ["Later", "Should", "Must"]

PLACEHOLDER_MARKERS = [
    "add chapters", "exact course/chapter list", "exact course list",
]


def is_placeholder(chapter_name: str) -> bool:
    lower = chapter_name.lower()
    return any(marker in lower for marker in PLACEHOLDER_MARKERS)


def most_advanced_status(a: str, b: str) -> str:
    ia = STATUS_ORDER.index(a) if a in STATUS_ORDER else 0
    ib = STATUS_ORDER.index(b) if b in STATUS_ORDER else 0
    return a if ia >= ib else b


def highest_priority(a: str, b: str) -> str:
    ia = PRIORITY_ORDER.index(a) if a in PRIORITY_ORDER else 0
    ib = PRIORITY_ORDER.index(b) if b in PRIORITY_ORDER else 0
    return a if ia >= ib else b


def run_import(raw_rows: list[dict]):
    init_db()

    # Step 1: merge duplicate (subject, name) rows
    merged = {}  # (subject, name) -> merged row dict
    for row in raw_rows:
        key = (row["Subject"], row["Chapter"])
        target = {
            "name": row.get("Exam / Target") if isinstance(row.get("Exam / Target"), str) else None,
            "targets_raw": row.get("Exam / Target"),  # may be JSON-string list
            "finish_by": row.get("FinishBy"),
        }
        if key not in merged:
            merged[key] = {
                "subject": row["Subject"],
                "name": row["Chapter"],
                "board_scope": row.get("Board / Preboard") or "None",
                "status": row.get("Status", "Not started"),
                "priority": row.get("Priority", "Should"),
                "target_rows": [target],
            }
        else:
            existing = merged[key]
            existing["status"] = most_advanced_status(existing["status"], row.get("Status", "Not started"))
            existing["priority"] = highest_priority(existing["priority"], row.get("Priority", "Should"))
            # keep the board_scope that isn't "None"/null if there's a conflict
            new_scope = row.get("Board / Preboard")
            if new_scope and new_scope != "None" and existing["board_scope"] in (None, "None"):
                existing["board_scope"] = new_scope
            existing["target_rows"].append(target)

    # Step 2: insert into DB
    with get_conn() as conn:
        exam_target_cache = {}  # name -> id

        def get_or_create_target(name: str, date_val: str | None):
            if name in exam_target_cache:
                return exam_target_cache[name]
            row = conn.execute("SELECT id FROM exam_target WHERE name = ?", (name,)).fetchone()
            if row:
                exam_target_cache[name] = row["id"]
                return row["id"]
            cur = conn.execute(
                "INSERT INTO exam_target (name, date) VALUES (?, ?)", (name, date_val)
            )
            exam_target_cache[name] = cur.lastrowid
            return cur.lastrowid

        inserted, placeholders = 0, 0
        for (subject, name), data in merged.items():
            placeholder_flag = 1 if is_placeholder(name) else 0
            if placeholder_flag:
                placeholders += 1

            cur = conn.execute(
                """INSERT INTO chapter (subject, name, board_scope, status, priority, effort_weight, is_placeholder)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (subject, name, data["board_scope"] or "None", data["status"], data["priority"], 3, placeholder_flag),
            )
            chapter_id = cur.lastrowid
            inserted += 1

            # link targets (dedupe target names per chapter too)
            seen_targets_for_chapter = set()
            for t in data["target_rows"]:
                raw = t["targets_raw"]
                names = []
                if raw:
                    try:
                        names = json.loads(raw) if isinstance(raw, str) else raw
                    except (json.JSONDecodeError, TypeError):
                        names = [raw] if isinstance(raw, str) else []
                for exam_name in names or []:
                    if exam_name in seen_targets_for_chapter:
                        continue
                    seen_targets_for_chapter.add(exam_name)
                    target_id = get_or_create_target(exam_name, None)
                    conn.execute(
                        """INSERT OR IGNORE INTO chapter_target (chapter_id, exam_target_id, finish_by)
                           VALUES (?, ?, ?)""",
                        (chapter_id, target_id, t["finish_by"]),
                    )

    print(f"Import complete: {inserted} chapters ({placeholders} flagged as placeholders, excluded from scoring).")


if __name__ == "__main__":
    # NOTE: Load your real 157-row export here. Two options:
    #   1. Paste the JSON array directly, replacing RAW_ROWS below.
    #   2. Save it to notion_export.json next to this file and load it:
    if len(sys.argv) > 1:
        with open(sys.argv[1]) as f:
            RAW_ROWS = json.load(f)
    else:
        print("Usage: python import_notion.py <path-to-notion-export.json>")
        print("Export your Notion database rows to JSON first (see README).")
        sys.exit(1)

    run_import(RAW_ROWS)
