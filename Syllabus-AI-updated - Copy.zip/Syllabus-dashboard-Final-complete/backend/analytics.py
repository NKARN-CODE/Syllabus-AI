"""
Analytics — every number here is computed directly from chapter rows.
No invented "accuracy" or "performance" scores: the data model has no
test scores, so those are deliberately not simulated. Revision rate is
used as an honest proxy for where you're struggling (real data: chapters
you've marked Needs revision), which is what "weakest subjects" means here.
"""
from db import get_conn
import activity as activity_mod


def overview():
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT subject, status FROM chapter WHERE is_placeholder = 0"
        ).fetchall()

    total = len(rows)
    tested = sum(1 for r in rows if r["status"] == "Tested")
    needs_revision = sum(1 for r in rows if r["status"] == "Needs revision")
    not_started = sum(1 for r in rows if r["status"] == "Not started")

    by_subject = {}
    for r in rows:
        s = by_subject.setdefault(r["subject"], {"total": 0, "tested": 0, "needs_revision": 0})
        s["total"] += 1
        if r["status"] == "Tested":
            s["tested"] += 1
        if r["status"] == "Needs revision":
            s["needs_revision"] += 1

    subject_breakdown = []
    for subj, s in sorted(by_subject.items()):
        pct = round(100 * s["tested"] / s["total"], 1) if s["total"] else 0
        subject_breakdown.append({
            "subject": subj, "total": s["total"], "tested": s["tested"],
            "needs_revision": s["needs_revision"], "pct_tested": pct,
        })

    # Weakest = lowest completion %, tie-broken by highest revision count.
    # Only subjects with at least one touched chapter are ranked — an
    # untouched subject isn't "weak," it's just not started yet.
    touched = [s for s in subject_breakdown if s["tested"] > 0 or s["needs_revision"] > 0]
    weakest = sorted(touched, key=lambda s: (s["pct_tested"], -s["needs_revision"]))[:3]

    touched_total = total - not_started
    revision_rate = round(100 * needs_revision / touched_total, 1) if touched_total else 0

    return {
        "total": total,
        "tested": tested,
        "not_started": not_started,
        "needs_revision": needs_revision,
        "completion_pct": round(100 * tested / total, 1) if total else 0,
        "subject_breakdown": subject_breakdown,
        "weakest_subjects": weakest,
        "revision_rate": revision_rate,
        "weekly_trend": activity_mod.weekly_trend(),
    }
