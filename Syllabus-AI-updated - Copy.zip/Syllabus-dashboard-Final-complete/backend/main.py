"""
Syllabus Thinking Dashboard — backend entrypoint.

Run with:  python main.py
Then open  http://localhost:8000  on this PC, or
           http://<this-pc-lan-ip>:8000  on your phone (same wifi).
"""
import os
from contextlib import asynccontextmanager
from datetime import date, datetime
from fastapi import FastAPI, HTTPException, UploadFile, File
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, List

from db import init_db, get_conn, QUICK_STATUS_MAP
from scoring import get_dashboard
import gamification
import activity as activity_mod
import analytics as analytics_mod
import exams as exams_mod
import goals as goals_mod
import resources as resources_mod
import ai_agent
import ai_settings
import worksheets as worksheets_mod
from app_paths import bundled_path


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    resources_mod.sync_all_chapters()  # self-healing: catches any chapter missing its resource set
    yield


app = FastAPI(title="Syllabus Thinking Dashboard", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # LAN-only tool, not exposed to the internet — fine to leave open
    allow_methods=["*"],
    allow_headers=["*"],
)


# ── Pydantic models ─────────────────────────────────────────────

class ChapterUpdate(BaseModel):
    subject: Optional[str] = None
    name: Optional[str] = None
    board_scope: Optional[str] = None
    status: Optional[str] = None
    priority: Optional[str] = None
    effort_weight: Optional[int] = None
    difficulty: Optional[str] = None
    notes: Optional[str] = None


class ChapterCreate(BaseModel):
    subject: str
    name: str
    board_scope: str = "None"
    status: str = "Not started"
    priority: str = "Should"
    effort_weight: int = 3
    difficulty: str = "Medium"
    notes: str = ""


class ExamTargetCreate(BaseModel):
    name: str
    date: Optional[str] = None
    time: Optional[str] = None
    priority: str = "Should"
    notes: str = ""
    exam_type: str = "Other"


class ExamUpdate(BaseModel):
    name: Optional[str] = None
    date: Optional[str] = None
    time: Optional[str] = None
    priority: Optional[str] = None
    notes: Optional[str] = None
    is_completed: Optional[bool] = None
    exam_type: Optional[str] = None


class ChapterTargetLink(BaseModel):
    exam_target_id: int
    finish_by: Optional[str] = None


class ExamChapterLink(BaseModel):
    chapter_id: int
    finish_by: Optional[str] = None


class StudySessionCreate(BaseModel):
    chapter_id: Optional[int] = None
    note: str = ""


class GoalCreate(BaseModel):
    title: str
    target_type: str = "custom"  # chapters_tested | subject_complete | custom
    subject: Optional[str] = None
    target_value: Optional[int] = None
    target_date: Optional[str] = None


class GoalUpdate(BaseModel):
    title: Optional[str] = None
    target_value: Optional[int] = None
    target_date: Optional[str] = None
    is_completed: Optional[bool] = None


class QuickStatusUpdate(BaseModel):
    quick_status: str  # not_started | practice | revision | completed


class ResourceToggle(BaseModel):
    is_done: bool


class AICommand(BaseModel):
    message: str


class AISettingsUpdate(BaseModel):
    api_key: str


class WorksheetScoreSubmit(BaseModel):
    score_pct: float


# ── Dashboard (three-question thinking system) ──────────────────

_last_urgent_ids = None  # process-local snapshot, fine for a single-user LAN app


@app.get("/api/dashboard")
def dashboard():
    global _last_urgent_ids
    result = get_dashboard()
    current_ids = {u["id"] for u in result["urgent"]}

    events = []
    if _last_urgent_ids is not None:
        cleared = _last_urgent_ids - current_ids
        if cleared:
            events += gamification.process_urgent_cleared(len(cleared))
    events += gamification.check_urgent_zero(len(current_ids))
    _last_urgent_ids = current_ids

    result["gamification_events"] = events
    return result


# ── Chapters ─────────────────────────────────────────────────────

@app.get("/api/chapters")
def list_chapters():
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM chapter WHERE is_placeholder = 0 ORDER BY subject, name"
        ).fetchall()
        chapters = [dict(r) for r in rows]

        # resource completion counts per chapter, for the row-level progress bar —
        # one query for everyone rather than N calls per chapter
        counts = conn.execute(
            """SELECT chapter_id, COUNT(*) as total, SUM(is_done) as done
               FROM chapter_resource GROUP BY chapter_id"""
        ).fetchall()
        counts_by_id = {c["chapter_id"]: {"total": c["total"], "done": c["done"] or 0} for c in counts}

        for ch in chapters:
            rc = counts_by_id.get(ch["id"], {"total": 0, "done": 0})
            ch["resource_total"] = rc["total"]
            ch["resource_done"] = rc["done"]

        return chapters


@app.get("/api/subjects")
def list_subjects():
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT DISTINCT subject FROM chapter WHERE is_placeholder = 0 ORDER BY subject"
        ).fetchall()
        return [r["subject"] for r in rows]


@app.get("/api/chapters/{chapter_id}")
def get_chapter(chapter_id: int):
    with get_conn() as conn:
        row = conn.execute("SELECT * FROM chapter WHERE id = ?", (chapter_id,)).fetchone()
        if not row:
            raise HTTPException(404, "Chapter not found")
        targets = conn.execute(
            """SELECT et.id as exam_target_id, et.name, et.date as exam_date, ct.finish_by
               FROM chapter_target ct JOIN exam_target et ON et.id = ct.exam_target_id
               WHERE ct.chapter_id = ?""",
            (chapter_id,),
        ).fetchall()
        result = dict(row)
        result["targets"] = [dict(t) for t in targets]
        result["resources"] = resources_mod.get_chapter_resources(chapter_id)
        return result


@app.post("/api/chapters")
def create_chapter(chapter: ChapterCreate):
    with get_conn() as conn:
        cur = conn.execute(
            """INSERT INTO chapter (subject, name, board_scope, status, priority, effort_weight, difficulty, is_placeholder, notes)
               VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?)""",
            (chapter.subject, chapter.name, chapter.board_scope, chapter.status,
             chapter.priority, chapter.effort_weight, chapter.difficulty, chapter.notes),
        )
        chapter_id = cur.lastrowid
    activity_mod.log(chapter_id, "created", to_status=chapter.status)
    resources_mod.sync_chapter_resources(chapter_id, chapter.subject)
    return {"id": chapter_id}


@app.patch("/api/chapters/{chapter_id}")
def update_chapter(chapter_id: int, update: ChapterUpdate):
    with get_conn() as conn:
        before = conn.execute("SELECT status FROM chapter WHERE id = ?", (chapter_id,)).fetchone()
        if not before:
            raise HTTPException(404, "Chapter not found")
        old_status = before["status"]

        fields, values = [], []
        for field in ("subject", "name", "board_scope", "status", "priority", "effort_weight", "difficulty", "notes"):
            val = getattr(update, field)
            if val is not None:
                fields.append(f"{field} = ?")
                values.append(val)
        if not fields:
            raise HTTPException(400, "No fields to update")

        # Any edit counts as touching the chapter — update last_studied.
        fields.append("last_studied = ?")
        values.append(date.today().isoformat())

        values.append(chapter_id)
        conn.execute(f"UPDATE chapter SET {', '.join(fields)} WHERE id = ?", values)

    events = []
    if update.status is not None and update.status != old_status:
        activity_mod.log(chapter_id, "status_change", from_status=old_status, to_status=update.status)
        events = gamification.process_status_change(old_status, update.status)
        with get_conn() as conn:
            tested_count = conn.execute(
                "SELECT COUNT(*) as n FROM chapter WHERE status = 'Tested' AND is_placeholder = 0"
            ).fetchone()["n"]
            row = conn.execute("SELECT subject FROM chapter WHERE id = ?", (chapter_id,)).fetchone()
            subject_total = conn.execute(
                "SELECT COUNT(*) as n FROM chapter WHERE subject = ? AND is_placeholder = 0", (row["subject"],)
            ).fetchone()["n"]
            subject_tested = conn.execute(
                "SELECT COUNT(*) as n FROM chapter WHERE subject = ? AND status = 'Tested' AND is_placeholder = 0",
                (row["subject"],),
            ).fetchone()["n"]
        events += gamification.check_tested_milestones(tested_count, subject_tested == subject_total)
        if update.status == "Tested":
            worksheets_mod.on_chapter_marked_completed(chapter_id)

    if update.subject is not None:
        resources_mod.sync_chapter_resources(chapter_id, update.subject)

    return {"ok": True, "events": events}


@app.delete("/api/chapters/{chapter_id}")
def delete_chapter(chapter_id: int):
    with get_conn() as conn:
        cur = conn.execute("DELETE FROM chapter WHERE id = ?", (chapter_id,))
        if cur.rowcount == 0:
            raise HTTPException(404, "Chapter not found")
    return {"ok": True}


@app.post("/api/chapters/{chapter_id}/targets")
def link_target(chapter_id: int, link: ChapterTargetLink):
    with get_conn() as conn:
        chapter = conn.execute("SELECT id FROM chapter WHERE id = ?", (chapter_id,)).fetchone()
        if not chapter:
            raise HTTPException(404, "Chapter not found")
        target = conn.execute("SELECT id FROM exam_target WHERE id = ?", (link.exam_target_id,)).fetchone()
        if not target:
            raise HTTPException(404, "Exam target not found")
        conn.execute(
            "INSERT OR REPLACE INTO chapter_target (chapter_id, exam_target_id, finish_by) VALUES (?, ?, ?)",
            (chapter_id, link.exam_target_id, link.finish_by),
        )
    return {"ok": True}


@app.delete("/api/chapters/{chapter_id}/targets/{target_id}")
def unlink_target(chapter_id: int, target_id: int):
    with get_conn() as conn:
        cur = conn.execute(
            "DELETE FROM chapter_target WHERE chapter_id = ? AND exam_target_id = ?",
            (chapter_id, target_id),
        )
        if cur.rowcount == 0:
            raise HTTPException(404, "That chapter/target link doesn't exist")
    return {"ok": True}


@app.patch("/api/chapters/{chapter_id}/quick-status")
def quick_status(chapter_id: int, update: QuickStatusUpdate):
    """The fast 4-option checklist control — maps onto the same status
    field the detailed editor uses, so nothing about scoring changes."""
    if update.quick_status not in QUICK_STATUS_MAP:
        raise HTTPException(400, f"quick_status must be one of {list(QUICK_STATUS_MAP.keys())}")
    real_status = QUICK_STATUS_MAP[update.quick_status]
    return update_chapter(chapter_id, ChapterUpdate(status=real_status))


@app.get("/api/chapters/{chapter_id}/resources")
def chapter_resources(chapter_id: int):
    with get_conn() as conn:
        if not conn.execute("SELECT id FROM chapter WHERE id = ?", (chapter_id,)).fetchone():
            raise HTTPException(404, "Chapter not found")
    return resources_mod.get_chapter_resources(chapter_id)


@app.patch("/api/chapters/{chapter_id}/resources/{resource_key}")
def toggle_chapter_resource(chapter_id: int, resource_key: str, update: ResourceToggle):
    if not resources_mod.toggle_resource(chapter_id, resource_key, update.is_done):
        raise HTTPException(404, "That chapter/resource combination doesn't exist")
    activity_mod.log(chapter_id, "study_session", note=f"{resources_mod.resource_label(resource_key)} marked {'done' if update.is_done else 'not done'}")
    return {"ok": True}


@app.get("/api/resources/overview")
def resources_overview():
    return resources_mod.overview()


# ── Study sessions (manual activity log entries, not tied to a status change) ──

@app.post("/api/study-sessions")
def create_study_session(session: StudySessionCreate):
    if session.chapter_id is not None:
        with get_conn() as conn:
            ch = conn.execute("SELECT id FROM chapter WHERE id = ?", (session.chapter_id,)).fetchone()
            if not ch:
                raise HTTPException(404, "Chapter not found")
            conn.execute(
                "UPDATE chapter SET last_studied = ? WHERE id = ?",
                (date.today().isoformat(), session.chapter_id),
            )
    activity_mod.log(session.chapter_id, "study_session", note=session.note)
    return {"ok": True}


# ── Activity / streak / heatmap ─────────────────────────────────

@app.get("/api/activity")
def get_activity(limit: int = 20):
    return activity_mod.recent(limit)


@app.get("/api/streak")
def get_streak():
    return activity_mod.streak()


@app.get("/api/heatmap")
def get_heatmap(days: int = 84):
    return activity_mod.heatmap(days)


# ── Analytics ────────────────────────────────────────────────────

@app.get("/api/analytics")
def get_analytics():
    return analytics_mod.overview()


# ── Gamification ─────────────────────────────────────────────────

@app.get("/api/gamification")
def gamification_state():
    return gamification.get_state()


# ── Subject map (syllabus overview chart) ───────────────────────

@app.get("/api/subject-map")
def subject_map():
    STATUSES = ["Not started", "Learning", "Practice", "Needs revision", "First pass done", "Tested"]
    with get_conn() as conn:
        rows = conn.execute("SELECT subject, status FROM chapter WHERE is_placeholder = 0").fetchall()

    by_subject = {}
    for r in rows:
        subj = r["subject"]
        by_subject.setdefault(subj, {s: 0 for s in STATUSES})
        by_subject[subj][r["status"]] = by_subject[subj].get(r["status"], 0) + 1

    result = []
    for subj, counts in sorted(by_subject.items()):
        total = sum(counts.values())
        tested = counts.get("Tested", 0)
        result.append({
            "subject": subj, "total": total, "tested": tested,
            "pct_tested": round(100 * tested / total, 1) if total else 0,
            "counts": counts,
        })
    return {"subjects": result, "status_order": STATUSES}


# ── Exams ────────────────────────────────────────────────────────

@app.get("/api/exams")
def get_exams():
    return exams_mod.list_exams()


@app.post("/api/exams")
def create_exam(exam: ExamTargetCreate):
    exam_id = exams_mod.create_exam(exam.name, exam.date, exam.time, exam.priority, exam.notes, exam.exam_type)
    if exam_id is None:
        raise HTTPException(409, "An exam with this name already exists")
    return {"id": exam_id}


@app.patch("/api/exams/{exam_id}")
def patch_exam(exam_id: int, update: ExamUpdate):
    fields = {}
    for field in ("name", "date", "time", "priority", "notes", "exam_type"):
        val = getattr(update, field)
        if val is not None:
            fields[field] = val
    if update.is_completed is not None:
        fields["is_completed"] = 1 if update.is_completed else 0
    if not exams_mod.update_exam(exam_id, fields):
        raise HTTPException(404 if not fields else 400, "Exam not found or nothing to update")
    return {"ok": True}


@app.delete("/api/exams/{exam_id}")
def remove_exam(exam_id: int):
    if not exams_mod.delete_exam(exam_id):
        raise HTTPException(404, "Exam not found")
    return {"ok": True}


@app.post("/api/exams/{exam_id}/chapters")
def exam_link_chapter(exam_id: int, link: ExamChapterLink):
    with get_conn() as conn:
        exam = conn.execute("SELECT id FROM exam_target WHERE id = ?", (exam_id,)).fetchone()
        if not exam:
            raise HTTPException(404, "Exam not found")
        ch = conn.execute("SELECT id FROM chapter WHERE id = ?", (link.chapter_id,)).fetchone()
        if not ch:
            raise HTTPException(404, "Chapter not found")
    exams_mod.link_chapter(exam_id, link.chapter_id, link.finish_by)
    return {"ok": True}


@app.delete("/api/exams/{exam_id}/chapters/{chapter_id}")
def exam_unlink_chapter(exam_id: int, chapter_id: int):
    if not exams_mod.unlink_chapter(exam_id, chapter_id):
        raise HTTPException(404, "That exam/chapter link doesn't exist")
    return {"ok": True}


# kept for backward compatibility with the old flat exam-target list
@app.get("/api/exam-targets")
def list_exam_targets():
    with get_conn() as conn:
        rows = conn.execute("SELECT * FROM exam_target ORDER BY date").fetchall()
        return [dict(r) for r in rows]


# ── Goals ────────────────────────────────────────────────────────

@app.get("/api/goals")
def get_goals():
    return goals_mod.list_goals()


@app.post("/api/goals")
def create_goal(goal: GoalCreate):
    goal_id = goals_mod.create_goal(goal.title, goal.target_type, goal.subject, goal.target_value, goal.target_date)
    return {"id": goal_id}


@app.patch("/api/goals/{goal_id}")
def patch_goal(goal_id: int, update: GoalUpdate):
    fields = {}
    for field in ("title", "target_value", "target_date"):
        val = getattr(update, field)
        if val is not None:
            fields[field] = val
    if update.is_completed is not None:
        fields["is_completed"] = 1 if update.is_completed else 0
    if not goals_mod.update_goal(goal_id, fields):
        raise HTTPException(404 if not fields else 400, "Goal not found or nothing to update")
    return {"ok": True}


@app.delete("/api/goals/{goal_id}")
def remove_goal(goal_id: int):
    if not goals_mod.delete_goal(goal_id):
        raise HTTPException(404, "Goal not found")
    return {"ok": True}


# ── AI Assistant ─────────────────────────────────────────────────

@app.post("/api/ai/command")
def ai_command(command: AICommand):
    if not command.message or not command.message.strip():
        raise HTTPException(400, "message is required")
    return ai_agent.run_agent_command(command.message.strip())


@app.get("/api/ai/settings")
def get_ai_settings():
    return ai_settings.get_settings_masked()


@app.put("/api/ai/settings")
def put_ai_settings(update: AISettingsUpdate):
    try:
        return ai_settings.save_settings(update.api_key)
    except ValueError as e:
        raise HTTPException(400, str(e))


# ── Retrieval worksheets ─────────────────────────────────────────

@app.post("/api/chapters/{chapter_id}/worksheets")
async def upload_worksheet(chapter_id: int, file: UploadFile = File(...)):
    with get_conn() as conn:
        if not conn.execute("SELECT id FROM chapter WHERE id = ?", (chapter_id,)).fetchone():
            raise HTTPException(404, "Chapter not found")
    if file.content_type not in ("application/pdf", "application/x-pdf") and not (file.filename or "").lower().endswith(".pdf"):
        raise HTTPException(400, "Only PDF files are accepted")
    file_bytes = await file.read()
    if not file_bytes:
        raise HTTPException(400, "Uploaded file is empty")
    try:
        worksheet = worksheets_mod.save_worksheet_file(chapter_id, file.filename, file_bytes)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return worksheet


@app.get("/api/chapters/{chapter_id}/worksheets")
def list_chapter_worksheets(chapter_id: int):
    with get_conn() as conn:
        if not conn.execute("SELECT id FROM chapter WHERE id = ?", (chapter_id,)).fetchone():
            raise HTTPException(404, "Chapter not found")
    return worksheets_mod.list_worksheets_for_chapter(chapter_id)


@app.get("/api/worksheets/due")
def worksheets_due():
    return worksheets_mod.list_due()


@app.get("/api/worksheets/upcoming")
def worksheets_upcoming():
    return worksheets_mod.list_upcoming()


@app.get("/api/worksheets/stats")
def worksheets_stats():
    return worksheets_mod.stats()


@app.get("/api/worksheets/{worksheet_id}/file")
def get_worksheet_file(worksheet_id: int):
    worksheet = worksheets_mod.get_worksheet(worksheet_id)
    if not worksheet:
        raise HTTPException(404, "Worksheet not found")
    if not os.path.exists(worksheet["file_path"]):
        raise HTTPException(404, "Worksheet file is missing on disk")
    return FileResponse(worksheet["file_path"], media_type="application/pdf",
                         filename=worksheet["original_filename"] or "worksheet.pdf")


@app.post("/api/worksheets/{worksheet_id}/score")
def score_worksheet(worksheet_id: int, submit: WorksheetScoreSubmit):
    try:
        result = worksheets_mod.submit_score(worksheet_id, submit.score_pct)
    except ValueError as e:
        raise HTTPException(400, str(e))
    worksheet = worksheets_mod.get_worksheet(worksheet_id)
    with get_conn() as conn:
        chapter = conn.execute("SELECT name FROM chapter WHERE id = ?", (worksheet["chapter_id"],)).fetchone()
    activity_mod.log(worksheet["chapter_id"], "study_session",
                      note=f"Retrieval worksheet {worksheet['slot_number']} for {chapter['name']} scored {submit.score_pct}%")
    return result


# ── Static frontend ──────────────────────────────────────────────

frontend_dir = bundled_path("frontend")
app.mount("/", StaticFiles(directory=frontend_dir, html=True), name="frontend")


if __name__ == "__main__":
    import uvicorn
    print("\n  Syllabus Thinking Dashboard")
    print("  Local:   http://localhost:8000")
    print("  Phone:   http://<this-pc-lan-ip>:8000  (same wifi)\n")
    uvicorn.run(app, host="0.0.0.0", port=8000)
