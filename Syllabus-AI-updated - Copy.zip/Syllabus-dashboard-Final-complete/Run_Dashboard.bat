@echo off
title Syllabus Command Center
cd /d "%~dp0"

REM ── Check Python is installed ──────────────────────────────
where python >nul 2>nul
if errorlevel 1 (
    echo.
    echo  ============================================
    echo   Python was not found on this computer.
    echo   Install it from https://python.org first
    echo   ^(tick "Add Python to PATH" during install^),
    echo   then run this file again.
    echo  ============================================
    echo.
    pause
    exit /b
)

REM ── Create venv only if missing ────────────────────────────
if not exist "backend\venv\" (
    echo.
    echo  Setting up Syllabus Thinking Dashboard for the first time...
    echo  This only happens once. Please wait.
    echo.
    python -m venv backend\venv
)

call backend\venv\Scripts\activate.bat

REM ── Verify dependencies are actually importable — not just   ──
REM ── "did we try to install them once before." A previous run  ──
REM ── that failed partway (no internet, interrupted, etc.) would ──
REM ── otherwise be skipped forever since the venv folder already ──
REM ── exists. This check is what actually caught last time's bug. ──
python -c "import fastapi, uvicorn, pydantic, webview" 2>nul
if errorlevel 1 (
    echo.
    echo  Installing/repairing dependencies — this can take a minute...
    echo.
    python -m pip install --upgrade pip
    python -m pip install -r requirements.txt

    python -c "import fastapi, uvicorn, pydantic, webview" 2>nul
    if errorlevel 1 (
        echo.
        echo  ============================================
        echo   Setup failed — required packages are still
        echo   missing after an install attempt.
        echo.
        echo   Common causes:
        echo    - No internet connection during install
        echo    - Antivirus blocked pip from writing files
        echo.
        echo   Try running this file again once you have a
        echo   stable internet connection. If it keeps
        echo   failing, delete the "backend\venv" folder
        echo   and run this file once more for a clean setup.
        echo  ============================================
        echo.
        pause
        exit /b
    )
)

REM ── One-time Notion import if the database doesn't exist yet ──
if not exist "backend\syllabus.db" (
    echo.
    echo  First-time setup: importing your syllabus data...
    echo.
    cd backend
    python import_notion.py ..\data\notion_export.json
    cd ..
)

REM ── Launch the dashboard as a native window ────────────────
REM (same server also listens on your LAN, so your phone can open
REM  it in a browser at the same time — the terminal prints the
REM  address to use)
echo.
echo  Launching Syllabus Command Center...
echo.
cd backend
REM pythonw suppresses the terminal: the native application window is the UI.
start "" /b venv\Scripts\pythonw.exe desktop.py
cd ..
