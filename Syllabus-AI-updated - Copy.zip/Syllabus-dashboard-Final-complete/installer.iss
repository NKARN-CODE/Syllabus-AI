; Inno Setup script for Syllabus Command Center.
;
; Build with: open this file in Inno Setup Compiler (free, from
; jrsoftware.org/isinfo.php) and click Compile, or run from the command
; line with: iscc installer.iss
;
; Produces: dist_installer/SyllabusDashboard-Setup.exe
;
; WHAT THIS INSTALLER DOES:
;   - Installs the PyInstaller-frozen app (everything under
;     dist/SyllabusDashboard/) into the current user's own Program Files
;     equivalent (no admin rights needed — see PrivilegesRequired below).
;   - Creates a Start Menu shortcut and an optional Desktop shortcut.
;   - Registers a real uninstaller in "Add or Remove Programs".
;   - Does NOT touch the user's actual data. Because app_paths.py already
;     keeps syllabus.db and uploaded worksheets in %LOCALAPPDATA%\
;     SyllabusDashboard — completely separate from wherever the app itself
;     gets installed — there is nothing here to preserve or migrate on
;     upgrade: reinstalling or updating never comes near the user's real
;     data, by construction, not by a special-case rule in this script.
;
; PREREQUISITE: you must run PyInstaller first (pyinstaller build_exe.spec)
; so that dist/SyllabusDashboard/ actually exists before compiling this.

#define MyAppName "Syllabus Command Center"
#define MyAppVersion "1.0.0"
#define MyAppPublisher "Syllabus Dashboard"
#define MyAppExeName "SyllabusDashboard.exe"
#define MyAppSourceDir "dist\SyllabusDashboard"

[Setup]
AppId={{8F3C2A1E-9B4D-4E7A-BB2F-5D6E9A1C3F70}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
; Per-user install, always, no admin prompt. This app has exactly one
; real user per PC (this is a personal study dashboard, not shared
; software), so PrivilegesRequired is fixed to "lowest" rather than
; offering the admin/non-admin override dialog — that override has a
; documented failure mode (install succeeds for one Windows account,
; shortcut invisible to others switching accounts). {autopf}/{autodesktop}/
; {autoprograms} all correctly resolve to their per-user forms once
; PrivilegesRequired is "lowest", matching the pattern used by every real
; Inno Setup script for this exact situation.
DefaultDirName={autopf}\{#MyAppName}
DefaultGroupName={#MyAppName}
DisableProgramGroupPage=yes
OutputDir=dist_installer
OutputBaseFilename=SyllabusDashboard-Setup
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=lowest

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Create a &desktop shortcut"; GroupDescription: "Additional shortcuts:"; Flags: unchecked

[Files]
; Recursively installs everything PyInstaller produced — the exe, its
; _internal folder (all bundled Python + libraries + the frontend
; assets), exactly as built. Nothing here is user data.
Source: "{#MyAppSourceDir}\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{autoprograms}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"
Name: "{autoprograms}\Uninstall {#MyAppName}"; Filename: "{uninstallexe}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Launch {#MyAppName} now"; Flags: nowait postinstall skipifsilent

[UninstallDelete]
; Only removes the installed PROGRAM files (Program Files folder). The
; user's real data lives entirely in %LOCALAPPDATA%\SyllabusDashboard,
; which this section deliberately never references — uninstalling the
; program leaves the user's chapters, exams, worksheets, and settings
; completely untouched, exactly like the app's data was never in the
; install folder to begin with.
Type: filesandordirs; Name: "{app}"
