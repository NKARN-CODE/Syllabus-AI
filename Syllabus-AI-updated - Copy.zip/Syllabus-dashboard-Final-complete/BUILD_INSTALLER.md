# Building a real Windows installer

This turns the app into an actual installable Windows program — a
`SyllabusDashboard-Setup.exe` you run once, that puts the app in your
Start Menu and (optionally) on your Desktop, with a normal uninstaller
in "Add or Remove Programs". No more double-clicking a `.bat` file.

You do this build ONCE (or again each time you want a new version to
install). Your day-to-day use afterwards is just opening the app from
the Start Menu like anything else.

## What you need first (both free, one-time installs)

1. **Python** — you already have this if `Run_Dashboard.bat` has worked
   before.
2. **Inno Setup** — download and install from
   [jrsoftware.org/isinfo.php](https://jrsoftware.org/isinfo.php). This
   is the tool that builds the actual `Setup.exe`.

## Step 1 — Install the packaging tool

Open a terminal in this project's root folder (where `Run_Dashboard.bat`
and `requirements.txt` live) and run:

```
pip install pyinstaller
```

This is a one-time tool install, separate from the app's own
dependencies in `requirements.txt` — you won't need to touch it again
unless you're rebuilding after future updates.

## Step 2 — Freeze the app into an .exe

Still in the project root:

```
pyinstaller build_exe.spec
```

This takes a minute or two. When it finishes, you'll have a new folder:
`dist\SyllabusDashboard\` — that's the whole frozen app, including a
`SyllabusDashboard.exe` you could already double-click to run directly
if you wanted to test it. (If you do test it this way first: it opens
its own window, no `.bat` file, no visible terminal.)

## Step 3 — Build the installer

Open `installer.iss` (double-click it — this opens the Inno Setup
Compiler if you installed it in Step 0) and click **Build → Compile**
(or just press **F9**).

This produces: `dist_installer\SyllabusDashboard-Setup.exe`

**That file is the actual installer** — the thing you'd send to
yourself, keep as a backup, or run on a fresh Windows install.

## Step 4 — Install it

Double-click `SyllabusDashboard-Setup.exe`. It will:
- Ask where to install (defaults to a sensible location, no need to
  change it)
- Ask if you want a desktop shortcut
- Install everything
- Offer to launch the app immediately when done

No admin password prompt — this installs just for your own Windows
account, which is all a personal app like this needs.

## Where your data goes now

Your chapters, exams, and worksheets now live in:
```
%LOCALAPPDATA%\SyllabusDashboard\syllabus.db
```
(You can paste that path directly into File Explorer's address bar to
see it.) This is deliberate — it means **reinstalling or updating the
app later never touches your real data**, since the app itself lives in
a completely separate folder. If you had already been using
`Run_Dashboard.bat` before doing this build, run the freshly-installed
app once, then close it — a copy of your existing data was already
included in this package, so it should already be there.

## Rebuilding after a future update

If you get updated source files later (a new zip from a future
conversation), just:
1. Replace the backend/frontend source files as usual
2. Repeat Steps 2 and 3 above
3. Run the new `SyllabusDashboard-Setup.exe` — it'll upgrade in place

Your data is untouched by this, for the reason above — it was never
inside the install folder to begin with.

## If something goes wrong

- **Step 2 fails with a Python error mentioning a missing package** —
  run `pip install -r requirements.txt` first, then retry.
- **Step 3's Inno Setup Compiler can't find `dist\SyllabusDashboard`** —
  you skipped or Step 2 failed silently; check its terminal output for
  errors and rerun it.
- **The installed app opens a window that says "can't reach this
  page"** — this shouldn't happen (the exact bug that caused this
  before was fixed as part of this build), but if it does, screenshot
  it and send it over.
- **Antivirus flags the installer or the exe** — this is common and
  expected for any small, newly-built, unsigned executable; it isn't a
  sign of a real problem. You can tell your antivirus to allow it.
